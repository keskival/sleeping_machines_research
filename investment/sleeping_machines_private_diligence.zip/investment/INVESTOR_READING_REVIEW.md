# Investor-reading review — 3 October 2026

## AGI opportunity and investor proof priorities — 4 October 2026

The main pitch now has 19 slides, followed by 17 optional diligence slides.
Slide 5 gives the long-term generalist-learning ambition its own diagram:
asynchronous sensing/action and language/reasoning exchange information through
shared persistent world state and learned rules. The first discriminating
proof is held-out transfer in each direction, with retention and matched
data/work controls. The diagram is an aspirational family composition; no
embodied-transfer or AGI demonstration is implied. PaLM-E and RT-2 primary
references attribute existing joint-learning precedents. Source access on
4 October is recorded per new reference; the old source cut-off is retained.

[The proof plan](INVESTOR_PROOF_PLAN.md) connects investor questions to current
evidence, the next decision-changing artifact and existing owner/admission
paths. Its focus is reproducibility, trained sparse economics, delayed
memory-credit fidelity and execution readiness. A small future simulated
bidirectional-transfer protocol is outlined without reserving compute. The
main proof-gate slide now specifies at least three seeds and trained parity
before measured serving cost. Financial/benchmark ledgers and the report PDF
are unchanged. Rendering peaked at 39,308 KiB; the new slide and revised gates
were visually inspected. No outreach, training or model runtime was performed.

## Family-level revision — 4 October 2026

The ambition/potential/execution rationale is now canonical in
[VALUATION_RATIONALE.md](VALUATION_RATIONALE.md). The investment case and
one-page pitch use the same €3M raise, €50M opening proposal and €100M stretch
scenario; prior $10M drafts are archived. The terms notes explain mechanism
and larger-data evidence, relevant founder experience, staged team execution,
correlated application risks and the absence of an independently established
price. The full deck adds an opportunity slide, with native irregular input,
asynchronous codecs, memory meta-learning and embodied/cognitive transfer
specified as hypotheses. Existing codec/event/VLA prior art and discriminating
proof conditions remain visible in the companion register. No application or
AGI demonstration, customer interest or financial ledger change is implied.


A follow-up review makes the adaptive query/fallback and full-work contract
explicit. The protocol appendix now distinguishes the frozen 10M ledger from
the completed 90M report result (1.857306 BPC, restricted 1M test, one seed);
it no longer calls that result pending. Financial assumptions and the main
comparison ledger are unchanged.


The earlier family-level revision had 18 main slides and 17 optional diligence slides. It added a
landscape diagram before the mechanism and benchmark slides, positioning the
family relative to recurrence/SSMs, attention/Transformers, sparse experts,
statistics/retrieval, adaptive memory/TTT and event systems. A second slide
shows units→layers→compositions→systems as choices under the same interface.
The title and notes identify a model family and computing substrate, not one
character-language experiment.

The common thesis is computational time, persistent private evidence, selective
activity and useful credit to unrealized alternatives. Heterogeneous dense and
sparse regions, local/barrier schedules, same-structure online learning and
broader structural adaptation have explicit conditions and status. Exact
function containment, trained quality and economic advantage remain distinct.
The report provides a 13-page visual family chapter and canonical twelve-field
specification with three complete illustrative members. None is represented
as new empirical evidence.

Financial assumptions and the completed benchmark ledger are unchanged.
Previous PDFs and publication records remain preserved. The earlier review
below describes the 16-slide main presentation that this revision extends.

## Earlier investor-reading revision

The first deck documented the research well but made an investor do too much
translation. It had 22 main slides, used internal configuration names in key
charts, described several markets before choosing a first product, and gave
speculative exit arithmetic a prominent role in the valuation argument.

The revised deck has **16 main slides and 16 optional diligence slides**. The
main pitch answers, in order: what economic problem we address, how the
architecture approaches it, what the experiments establish, what we would
sell first, why a hardware ecosystem might care, who executes the work, what
can fail, and what €3M is intended to establish.

Concrete editorial changes:

- Replaced internal names such as p32/d4 with “small model,” “more memory,”
  “deeper model,” “medium model” and “best quality.” An appendix defines their
  widths, layers and memory slots and maps them to reproducible records.
- Explained bits per character as prediction error before showing the chart;
  kept lower-is-better directions and clearly distinguished training arithmetic
  from service cost. Presented near-recurrent quality alongside its extra work.
- Removed conversational corrections such as “LUMI is not a model.” The AMD
  account now directly states the relevant positive precedent and its scope.
- Chose a **product hypothesis**: model and runtime for low-batch language
  inference on existing hardware. This is an evaluation target, not validated
  demand or a demonstrated region of commercial advantage.
- Replaced main-deck billion-euro spend and hundred-million-device examples
  with annual economics per prospective customer: €1M eligible cost, €200k
  assumed gross saving, €40k assumed license, €160k buyer benefit before
  transition costs. Twenty-five such deployments imply €1M annual revenue.
  All are explicit assumptions; no revenue, interest or willingness to pay exists.
- Connected the budget and hiring to three proof gates: scale/replication,
  complete execution economics, and external evaluation/adoption.
- Kept the €50M proposed pre-money and its 5.66% initial investor stake in the
  financing slide. Moved conditional €10B/€50B exits, the €100M stretch and
  reverse-calculated success odds into the appendix. Those calculations do
  not prove a valuation. The small ownership stake may limit investor fit;
  changing the story does not resolve price or financing-market uncertainty.
- Preserved the detailed credit, capacity, sparse execution, online-learning,
  negative-result and protocol disclosures in the appendix and notes. Added
  PDF bookmarks for a short main-pitch reading path.

This is an editorial revision using the **same frozen completed evidence**.
It makes no new research or measured economic claim. The ambition remains a
model/runtime/temporal computing substrate across cloud and embodied systems.
Commercial application quality, measured energy/traffic, trained sparse parity,
longer-scale evidence, retention, exclusive rights and customer adoption remain
the substantive questions investors must evaluate.

Remaining diligence cannot be fixed by wording: founder availability, corporate
entity and cap table, contribution/employer IP rights, intended licenses, actual
compute and hiring quotes, modern replicated controls, service measurements,
and prospective evaluation partners. Earlier public disclosures remain relevant
despite the repository now being private. This work makes no external contact
and does not publish the deck.
