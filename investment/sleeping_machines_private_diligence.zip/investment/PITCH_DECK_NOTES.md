# Sleeping Machines — full pitch deck and diligence notes


Proposed raise: €3M. Bullish negotiating case: €50M priced pre-money; €100M stretch scenario.


The current valuation rationale is VALUATION_RATIONALE.md. The €50M proposal prices the platform ambition and execution case, not benchmark scores or a sum of application markets.


All financial outcomes, budgets and milestone timelines are assumptions. No customer interest has been reported. Repository is private by founder instruction on 3 October 2026. This deck is a private review artifact; distribution and any future publication require a considered disclosure decision.


Benchmark/financial ledger: frozen 3 October 2026; current public wins are scoped on their slides. Forward-credit component evidence:11 October2026, source-bound in forward_credit_evidence_20261011.json. The protocol notes separately scope the report's completed 90M result. Opportunity and valuation rationale updated 4 October; no pending training scores enter the deck.


Reading guide: slides 1–29 form the investor pitch; the remaining slides are optional technical and financial diligence.


## 1. Sleeping Machines

The next general-purpose substrate for machine intelligence.

Sleeping Machines aims to be the next general-purpose substrate for machine intelligence: one trainable architecture, learning rule and execution model spanning language and reasoning, multimodal world models, embodiment, event-native analytics, continual learning, communication, self-design and datacenter, edge and clockless hardware. Private review deck. The founder proposes a €3M raise. €50M priced pre-money is the central bullish negotiating thesis developed here; €100M is a stretch scenario, neither an independent fair-value appraisal nor an investor offer. The research evidence is exploratory and single-seed. No customer interest has been reported. No investor, vendor or customer has been contacted in preparing this deck.


## 2. One substrate for learning, representing and executing intelligence.

Different forms of experience can teach reusable computations within the same learner.

AGI here means the long-term ambition of broadly transferable learning and competence across domains, not a claim that a shared graph or computational universality guarantees intelligence. The visual is a proposed family composition, not an implemented robotics system. Common content/time/address/state interfaces can connect asynchronous sensory and motor events with language and deliberation; local dense regions, joins and batching remain available. No global periodic tick is required by the family, but causal ordering, timers and task/actuator deadlines remain. Fast persistent state and slower learned rules offer a path to online adaptation and memory-policy learning; fully native sparse asynchronous learning is still a research target. The opportunity is to test whether embodied experience teaches transferable causal, geometric and planning abstractions and whether cognitive learning improves action, using shared representations and credit. Both directions require separate held-out, matched-data/work comparisons with joint dense/VLA, isolated-module and stopped-credit controls, including retention, replay and system resources. Existing PaLM-E and RT-2 demonstrate related joint-learning or web-to-control precedents; we do not claim that conventional models cannot integrate these domains. Neither precedent establishes our proposed motor-to-cognitive transfer or our cost advantage. Shared parameters do not establish AGI, and no project embodied-transfer/robot-control experiment has completed. Platform upside is conditional and correlated with the same unresolved learning and execution risks; it is not an extra independent valuation or an assigned probability. See INVESTOR_PROOF_PLAN.md for staged work and the smallest simulated transfer protocol; no queue or new compute is reserved by this slide. Editorial update 5 October: the platform thesis encompasses heterogeneous representations, shared learning and execution semantics, and small-to-large operating regimes. Mixed-type tabular success would be evidence of this unification; numeric-only tabular fits are not that proof. Joint skill transfer, clockless learning hardware and scaling advantages require their own completed comparisons.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.

- [T4: Driess et al. — PaLM-E: An Embodied Multimodal Language Model](https://arxiv.org/abs/2303.03378) — Joint embodied, vision and language training with positive transfer; a precedent, not evidence for this substrate or motor-to-general-cognition transfer.

- [T5: Brohan et al. — RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control](https://arxiv.org/abs/2307.15818) — Joint vision/language/action learning transfers web knowledge to robotic control. Neither an AGI demonstration nor evidence for our resource advantage.


## 3. 13 public benchmark wins, and language is next.

Official dataset/protocol means beat the best published single model; 53 of 61 seed/split scores ahead.

**13 public benchmark wins** against the best published single-model results on official dataset/protocol entries. Across these winning entries,53 of61 seed/split scores are ahead;wins compare dataset means,not every individual run. The four added Bosser–Ben Taieb wins are Wikipedia,Github,Stack Overflow and LastFM. Wikipedia/Github also beat stronger composite targets;Stack Overflow/LastFM beat the best single-model totals. B4 uses recorded-data density scoring;these are quality wins,with complete work unaudited. [Source-bound headline ledger](investment/public_benchmark_headlines.json). B4 split counts ahead of best single:Wikipedia5/5,Github2/5,Stack Overflow2/5,LastFM4/5. Means define the wins;individual official splits are not independent trials. The current aggregate is53/61. Sources:public_benchmark_headlines.json and b4_developed_evidence.json.

- [R_B1: EasyTPP battle dossier and sealed TEST results (6 October 2026)](../experiments/B1_EASYTPP.md) — Official EasyTPP splits and per-event log-likelihood protocol; 5 seeds, TEST scored once per seed at best DEV; published references with sources; per-event compute counted from released layer definitions.

- [R_B2: Irregular clinical time series battle dossier and five-split TEST results (7 October 2026)](../experiments/B2_IRREGULAR_TS.md) — Raindrop P19 official splits; pre-registered protocol; validation selection; TEST once per split; published references from MTM (arXiv 2509.17809).

- [R_HEADLINES: Source-bound current public benchmark wins](public_benchmark_headlines.json) — Official dataset/protocol means;53/61 seed/split scores ahead. B4 recorded density,composite and single-model wins distinguished.


## 4. Public-leaderboard wins: timed event data (EasyTPP).

Public benchmark (ICLR 2024), official splits. Log-likelihood per event in nats: higher is better. Sealed test, 5 seeds.

Source: experiments/B1_EASYTPP.md. Pre-registered reporting rule (fixed before any 5-seed TEST aggregate): single-model TEST mean ± sd over 5 seeds and the uniform 5-seed predictive mixture, with per-event inference MACs beside S2P2. A mixture is a matched-compute result only where 5x our MACs <= S2P2 (Taxi 0.41x, Retweet 0.29x); elsewhere it is a higher-compute (pure accuracy) result. Taobao single model 1.3991 ± 0.0025 vs best published 1.318 ± 0.017 (IFTPP), S2P2 1.304; best time (2.753) and mark (-1.353) LL; 24,362 vs 26,016 MACs/event. Taxi single 0.5250 ± 0.0010 vs S2P2 0.522 ± 0.004 at 20,708 vs 249,856 MACs/event; 5-seed mixture 0.5363 beats every published model on total, time and mark LL. StackOverflow: single model -2.1809 ± 0.0055 (behind by 0.018), mixture -2.154 at 4.6x S2P2 MACs. Amazon v5 TEST 0.7008 ± 0.0263 (3 seeds) vs S2P2 0.781; v8 logistic-window clocks DEV 0.768 vs v5 0.724, TEST protocol next. Retweet: a v3 DEV lead was withdrawn after the recording-grid audit (scores fell when event times were dequantized within their recording resolution); Taxi and Taobao pass that audit. B1 pass criterion: best published LL on at least 2 of 5 datasets with 5 seeds. Update 6 Oct 22:00: StackOverflow v12 (continuous-time state clock, 3 layers): single model -2.1444 ± 0.0037 vs S2P2 -2.163 ± 0.009 (+0.019 nats), best mark LL, time level with the best, at 1.26x S2P2 per-event MACs (36,732 vs 29,216): a confirmed pure-accuracy win (5 seeds, audit-clean); 5-seed mixture -2.1113. The earlier v5 row (mixture -2.154 at 4.6x) is superseded. Update 7 Oct 16:30: Amazon v18 (delay windows anchored to their gap component; pre-registered protocol, one run per seed, no restarts, best-DEV checkpoints scored once on TEST after exact DEV reproduction): 0.8028 ± 0.0007 vs S2P2 0.781 ± 0.011 (+0.022), all five seeds ahead (0.8021-0.8036), best published time (2.657 vs 2.652) and mark (-1.854 vs -1.871) LL; EasyTPP Monte Carlo estimator 0.8037-0.8060; 35,936 vs 125,568 MACs/event (0.29x). All five EasyTPP datasets won.

- [R_B1: EasyTPP battle dossier and sealed TEST results (6 October 2026)](../experiments/B1_EASYTPP.md) — Official EasyTPP splits and per-event log-likelihood protocol; 5 seeds, TEST scored once per seed at best DEV; published references with sources; per-event compute counted from released layer definitions.


## 5. The same model also generates realistic event streams.

Taxi trips: real held-out sequences and sequences generated by racing the model's clocks from the same first event.

Source: experiments/tpp/generate_race.py; results/tpp/generate/taxi_v5_s0_generated_200.json and taxi_timeline_examples.json. Each clock draws its firing time (Exp(rate*w); defective delayed clocks fire with probability pi at LogNormal(mu, sigma)); the earliest clock sets time and type; the event feeds back into memory. The model's training likelihood is exactly this competing-risks process.

- [R_B1: EasyTPP battle dossier and sealed TEST results (6 October 2026)](../experiments/B1_EASYTPP.md) — Official EasyTPP splits and per-event log-likelihood protocol; 5 seeds, TEST scored once per seed at best DEV; published references with sources; per-event compute counted from released layer definitions.


## 6. Public-benchmark win: ICU sepsis prediction (P19).

PhysioNet 2019, 38,803 ICU stays, 34 irregularly sampled channels, 4.2% positive. Five official splits, TEST once per split.

Source: experiments/B2_IRREGULAR_TS.md; pre-registered protocol (v3 defaults, five official Raindrop splits, validation-AUROC selection, TEST once per split). Per split AUROC 0.942/0.923/0.883/0.926/0.907. Event-native classifier: each time step is an event; addressed channel memories carry sufficient statistics (count, mean, min, max, first, last, trend, staleness) and decay with elapsed time; typed comparisons; silence (time since last measurement) is an input. Temporal memory layer imported from the EasyTPP model (same code, same size). Literature check 7 Oct 2026: arXiv 2602.19531 reports about 0.897 with its own 5-fold CV (different protocol); QuITE does not report P19. PAM won (accuracy 0.978 vs 0.975); P12 is behind MTM on AUROC. Complementarity test (8 Oct, curie, five splits, paired): full 0.916/0.644; statistics-only network 0.900/0.572 (5/5 splits lower, t 5.3 / 31); trees on the same statistics 0.914/0.618 (ours ahead on AUPRC 5/5, t 4.2); rerun matches AWS AUROC within 0.0004 on all splits.

- [R_B2: Irregular clinical time series battle dossier and five-split TEST results (7 October 2026)](../experiments/B2_IRREGULAR_TS.md) — Raindrop P19 official splits; pre-registered protocol; validation selection; TEST once per split; published references from MTM (arXiv 2509.17809).


## 7. Beats the saved Transformer baselines at a fraction of the compute.

Wikipedia text (text8); same data and test set for all. Error: bits/char (bpc) or sMAPE %; lower is better.

Matched-compute rows follow experiments/WIN_CRITERIA.md: our run uses no more compute than the reference on the stated axis and scores better. Evaluation window T=256 characters for every model. "Passes" = epochs over the 10M training characters. sMAPE = symmetric mean absolute percentage error (NeuroBench Mackey-Glass, tau 17). Training compute: whole-fit estimate; inference: per-position (native exact winner-only trace). The 4-pass Transformer comparison uses a 6-pass native run with 1.5x the optimizer updates; an update-matched rerun is queued. Second seeds are queued. The 90M row is an efficiency point, not yet a matched-compute result. NeuroBench Mackey-Glass is partial (20 of 30 official repeats). Update 5 Oct: the first completed tuned dense control (LSTM-384, lr .003, warmup, 6 passes, 254 TF) scores 1.840 versus our 1.888 at 352 TF: a loss at matched training compute, stated plainly. Five more tuned arms are running; the LSTM's stateful scoring context is being aligned; native runs were not learning-rate tuned either, and a matching native lr check is queued. Update 5 Oct 00:40: second tuned arm LSTM-512 4.5 passes, 324 TF, test 1.826 (validation 1.769, leading the group); native 1.888 at 352 TF. Update 5 Oct 03:45: budget B (<=107 TF) first tuned arm LSTM-384 2.5 passes 1.915 vs native 1.955: also a loss. Final 5 Oct 04:40: P0-6 complete; validation selection confirmed with windowed LSTM validation (curie). Budget A: tuned LSTM-512 1.825 beats native 1.888; tuned Transformers best 1.996 (native better at 102% compute). Budget B: tuned LSTM-384 1.915 beats native 1.955; best tuned Transformer 2.215. P0-2 (p128/d4 4-pass) 1.907 at 411 TF: loss. Update 5 Oct 08:45: P0-1 90M native 4-pass 1.800 at 0.97 PF (efficiency point; 4x compute bought .057 bpc from the 1-pass 1.857). NeuroBench Mackey-Glass (draft-stage configuration, official 30 repeats): 14.84 sMAPE vs LSTM 13.37 and ESN 14.79; recorded in FINDINGS and the evidence pack; moved off the headline table under the maturity gate (VALUE_PLAN.md, 6 Oct). Update 6 Oct: 90M budget D (about 2.1 PF): native p96/d4 1.783 vs tuned Transformer-256x4 1.811 at 1.06x compute (near-matched win) and vs Transformer-192x4 1.704 (loss); at budget C (about 0.96 PF) native 1.800 loses to LSTM-512 1.729 and TF192x4 1.780 (report Part I, section 4.3).

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.


## 8. Event-driven models aimed for parity. Ours beats small Transformers on compute.

Published event-driven and spiking language models, as reported by their authors, beside our completed result.

Literature check (web search, 4 October 2026), not a systematic review. Prior event-driven/spiking language models report parity or a gap against conventional models; we found none reporting a Transformer win at lower counted compute. Our claim is scoped: text8, 10M training characters, models under 1M parameters, single seeds, baselines trained by the project (tuned baselines at our budgets are running); LSTM-512 (1.799 bpc) remains ahead at 10M and both references remain ahead at 90M. Prior-work compute figures use different conventions and hardware and are not compared numerically. Scope (5 Oct): our comparison is at ~1M parameters and 10M characters against baselines we trained; the prior systems were evaluated at 100M-1.5B parameters. Tuned LSTMs currently beat our model (1.826 vs 1.888 bpc).

- [P1: Nazeer et al., Language Modeling on a SpiNNaker 2 Neuromorphic Chip (2023)](https://arxiv.org/abs/2312.09084) — Event-based GRU on a neuromorphic chip; authors: first neuromorphic language model to match LSTMs.

- [P2: Zhu et al., SpikeGPT: Generative Pre-trained Language Model with Spiking Neural Networks (TMLR 2024)](https://arxiv.org/abs/2302.13939) — 216M-parameter spiking language model; authors: competitive with non-spiking models; fewer operations projected on neuromorphic hardware.

- [P3: Abreu et al., Neuromorphic Principles for Efficient Large Language Models on Intel Loihi 2 (2025)](https://arxiv.org/abs/2503.18002) — 370M MatMul-free model quantized for Loihi 2; no accuracy loss versus its unquantized version.

- [P4: Richter et al., Event-Driven Language Models with Sparse Neural Activity for Neuromorphic Hardware (2026)](https://arxiv.org/abs/2608.30439) — Thresholded activations in quantized linear-attention models; comparable to dense models with up to 4x fewer effective operations.

- [P5: Zhao et al., Large Language Models with At Most One Spike per Neuron (2026)](https://arxiv.org/abs/2609.05151) — Time-to-first-spike coding on GPT-2/BERT, up to 1.5B parameters; authors report a clear perplexity gap on language modeling.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.


## 9. Intelligence must compose across experience and execution.

A common substrate connects what a model learns with how and where it computes.

This is the problem definition and investment hypothesis. It is not a claim that all existing architectures perform dense work or lack memory. MoE already separates available parameters from selected computation; recurrent and selective-state models already retain state. Our proposed contribution is a temporal race/state/alternative-credit construction and its tested consequences. Software and hardware benefits must be evaluated with tuned incumbents under the same workload boundaries.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.

- [S6: Google — Eighth-generation TPU architecture announcement](https://blog.google/innovation-and-ai/infrastructure-and-cloud/google-cloud/eighth-generation-tpu-agentic-era/) — TPU 8t/8i, model–hardware co-design and sparse MoE infrastructure. Existing internal capability creates both potential fit and competition.


## 10. One model family across today's architectural landscape.

Our approach combines strengths of today's main model types.

This is the whole-family position, not a claim that every implemented member contains every incumbent. The envelope intersects recurrent/SSM, attention, sparse expert, statistical/retrieval, adaptive-memory and temporal systems. Supported dense reference blocks and synchronous barriers are permitted endpoints. The proposed differentiation is a common stateful temporal/selection/credit construction and its eventual quality/resource behavior. Known primitives have prior art; wrapping a reference predictor establishes no advantage. Computational universality is not a strictly larger class than all finite computable predictors. The technical report states operator, state, precision and schedule conditions. Current language fits illustrate one branch; joint TTT, multimodal integration, general morphing and clockless hardware economics are separate milestones. Containment (7 Oct 2026): a Mamba selective scan is the family member in which each token arrives after a learned content-dependent delay, memories decay over elapsed time, and writes/reads are content-addressed; experiments/theory/mamba_containment_check.py reproduces Mamba-1 and Mamba-2 selective scans to 4e-13 (float64); rotating memories extend the class. Attention: an exponential race samples exactly from a softmax and delay-coded aggregation reproduces softmax attention over delivered keys (THEORY notes 08, 151). Neither identity claims speed or learning-efficiency parity at scale.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 11. Choose the right computation in each region.

One family can mix selective temporal programs with rich interaction and causal memory.

The local choices form a generative design space, not a catalogue of unrelated benchmark models. Selective and full-support regions can coexist; synchronous barriers are optional local schedules inside event semantics. The same model structure supports causal parameter updates and batching. Current state/statistical adaptation and an online pilot are scoped evidence; they do not establish fully asynchronous on-chip learning or a general TTT gain. Learned event routes already adapt execution inside a fixed graph; operator selection, reception/depth choice, allocation and growth/pruning require future utility, state/version migration and resource accounting. The formal core defines twelve fields and compatibility rules, and illustrative complete members show contrasting constructions without adding benchmark evidence. Preserve computation, representation and trainability through interfaces; forward equality, learning preservation and lower cost are distinct contracts. Learned memory/scheduling can be viewed as fast-state adaptation governed by slow trained rules, drawing on memory-augmented meta-learning and TTT. The opportunity register defines native irregular ingestion, asynchronous codecs and joint embodied/cognitive paths with explicit first proofs. The prior-art boundary and full work/bit accounting are stated in the report.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 12. Messages race. Selected memories update. Alternatives learn.

A simple event loop connects representation, timing and sparse computation.

This construction combines familiar vector operations with temporal computation and sparse state. Separate keys determine addressing; values determine delivered content. Counterfactual credit gives unrealized alternatives a learning signal without softening the hard forward route. The present implementation is not a physical asynchronous machine: autograd, shared training windows, clipping and Adam remain. Winner-only inference still scores all candidate keys.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 13. Race-based language prediction beats the dense hybrid.

Same 4M fresh GPT-2/FineWeb tokens, order and schedule; one development seed.

The winning CERL member uses two temporal-memory carrier layers and BPTT; it is not the completely native deep event-local learner. The separate eight-layer fully native learner completes 64K targets at 7.0473 flagship NLL and continues with persistent queried memory and local producer credit. Compare each model only under its declared data and evaluation protocol. The two-page composition demonstration explains events as scheduling and persistent memories as content. Actual-child delayed credit is implemented with no new parameters; its numerical and acquired-learner recovery gate is queued. The next investment proof is better held-out prediction and relations from deeper refinement at disclosed work, not a claimed scaling result. Companion: sleeping_machines_composition_demonstration.pdf. Work-accounting correction: the native FlopCounter probe backpropagates NLL without the exploration auxiliary used in acquisition. Treat7.7M as a partial registered operator subtotal;no complete-fitting-work advantage follows.

- [R1CERL: Completed causal race language development result, 16 October 2026](../experiments/results/token_language/curie_r1_cerl_4M_s0_20261016_v1.json) — Same 4M-token data/order/schedule and development protocol, one seed; two temporal-memory carrier layers and one cause-race level. Estimated arithmetic, not hardware measurements.

- [R1NATIVE: Fully native deep local-learning implementation](local_native_language_evidence.json) — Conditional eligibility,native event/gradient parity and32targetoptimizer gate;no predictive quality claim.


## 14. Forward computation teaches more economical credit.

Real tokenized language: prospective credit accuracy and measured acquisition cost.

Accuracy: frozen diagonal optimizer-state transport,8 fresh TRAIN-tail prefixes/64context/48targets/65routes, source50257 GPT-2 vocabulary/native2layers,64dim lexical learner; MSE1.927e-10 vsstatic1.172e-8 andreference7.407e-9, paired95% improvements positive, all8prefixes improve. Acquisition: separate4prefixes/3rotated repeats,26.933s exact vs12.893s transported+factual;165.164 vs10.775 supportedGFLOPs, approximate predictor/exact actual correction. Controller: fixed37,377parameters/four originalprefixes,conditional action-noise variance2.463e-6 static vs5.470e-7 transport; mean error<=1.1e-19. Source pretraining/oracle labels/gates extra; all-key/vocabulary work retained. Early small route-controller fits have no confirmed held-out task utility gain. These are scoped component advances, not a language benchmark or matched-quality whole-fit scaling win. Rank-eight block covariance additionally passes on eight separate fresh prefixes: MSE1.883e-11 versus diagonal9.539e-11,80.3% lower, paired95%positive; kernel1.178 versus0.927GFLOPs per48targets, basis0.056s/0.463GFLOPs/16.88MiB. No newly fitted critic claim. Actual online update-function episodes and their current utility gate are in the source-bound packet; this does not establish whole-native quality/work superiority. The unchanged update rule passes on eight NEW512-target private episodes: online-minus-frozen improvement0.008656 nats/target, paired95%[0.002287,0.014536],6/8 improve. It inherits1024-target pretraining. Adam still leads by0.024351. Actual native group-scale optimizer learning improves final TaxiDEV quality9/9 across three seeds anddepth2/4/8: mean gains0.012136/0.007631/0.005258 nats/target vsfixedAdam;180parameter controller, all1400TRAIN sequences32events/threepasses,128DEV sequences. It retains exact actor backprop and currently increases CPU time. Frozen acquired policy is tested on fresh actor initializations with inherited acquisition charged. Generated core credit is a separate construction: online beats frozen6/6width8 cases but nativeAdamW superiority is unconfirmed; width32fails head-only. Four learned event queries and future-trained amplitude/momentum target that failure. No matched-quality efficient deep-learning or sparse hardware claim. Matched acquired-core/head-only controls for new event optimizers lose7/8; an earlier cross-configuration depth8 deep-benefit interpretation is corrected. Local variants stop; selected unchanged recipe now runs fresh actor/full1400TaxiTRAIN/threepasses/depth8/16/32 with matched heads/frozen/own-nativeAdamW and acquisition-inclusive work. No pending result promoted.

- [RLC: Completed forward-credit and optimizer-transport evidence (11 October2026)](forward_credit_evidence_20261011.json) — Eight fresh TRAIN-prefix accuracy, four-prefix three-repeat corrected acquisition and fixed connected-controller conditional variance; component evidence, no task-learning-speed or hardware-energy claim.


## 15. If this scales, adaptation becomes a routine capability.

Conditional economic and industrial opportunity; the proof path is explicit.

These are contingent implications, not customer demand, product readiness, revenue, energy savings or economy-wide forecasts. One shared forward response can teach many alternative optimizer trajectories; connected credit functions may generalize from learned representations and adapt to causal regime changes. Require equal/better held-out prediction per total learning work, larger-model/data replication, whole-system energy/traffic measurement and application evaluation. Retain the general-purpose ambition across language/reasoning, multimodal world models, embodiment, analytics, continual learning, communication, self-design and hardware.

- [RLC: Completed forward-credit and optimizer-transport evidence (11 October2026)](forward_credit_evidence_20261011.json) — Eight fresh TRAIN-prefix accuracy, four-prefix three-repeat corrected acquisition and fixed connected-controller conditional variance; component evidence, no task-learning-speed or hardware-energy claim.


## 16. One family wins across different kinds of data.

One construction: memories that evolve with elapsed time, sparse addressed writes, typed comparisons, races. The P19 classifier reuses the event model’s temporal memory layer, same code and size.

Positioning: S2P2 (NeurIPS 2025, GE HealthCare and UC Irvine) is evaluated only on marked event likelihood. Its parent family, deep state-space models, is general on dense sequences and language; published SSM results do not, to our knowledge, show one model winning event likelihood and sparse clinical classification together. Track G (experiments/GENERALITY_PLAN.md): self-supervised event pretraining on unlabeled clinical records transferred to mortality prediction with fewer labels (G1); one model across five event datasets (G2); PAM wearable sensors (G3); event-to-event transfer (G4). Update 8 Oct 07:40: PAM (wearable activity recognition) five-split TEST protocol, pre-registered 7 Oct 19:42 UTC: accuracy 0.9775 ± 0.0074, F1 0.9803 ± 0.0080 vs MTM 0.975 ± 0.002 / 0.976 ± 0.002, 46,316 parameters; per split 0.979, 0.981, 0.981, 0.981, 0.964 (split 4 behind). Win under the pre-registered rule (mean accuracy ahead).

- [R_B1: EasyTPP battle dossier and sealed TEST results (6 October 2026)](../experiments/B1_EASYTPP.md) — Official EasyTPP splits and per-event log-likelihood protocol; 5 seeds, TEST scored once per seed at best DEV; published references with sources; per-event compute counted from released layer definitions.

- [R_B2: Irregular clinical time series battle dossier and five-split TEST results (7 October 2026)](../experiments/B2_IRREGULAR_TS.md) — Raindrop P19 official splits; pre-registered protocol; validation selection; TEST once per split; published references from MTM (arXiv 2509.17809).

- [R4: Completed cross-domain headline evidence — 6 October 2026](../report/unification_headline_evidence_20261006_v1.json) — Fourteen SHA-bound completed results, selections, generic controls and artifact receipts. Three-seed FAS v1 wins; synthetic typed witness; two-seed1M token-language learning and memory utility. Separately fitted instances.


## 17. Respect types. Race decisions. Compose learned state.

Meaningful comparisons become events before evidence enters a common neural representation.

Theory and39stdlibcontracts in experiments/theory/TYPED_SEMANTICS_AND_RACE_COMPOSITION_20261006.md and experiments/results/diagnostics/typed_semantics_composition_contracts_20261006_v1.json. A raw affine gate cannot use arbitrary nominal codes and remain invariant to every code permutation with fixed parameters. Categorical embeddings and feature-specific neural maps are legal alternatives. Under invariant typed event adapters, identical causal core/state/RNG produce identical outputs. Learning additionally requires appropriate preprocessing, initialization and optimizer coordinates. Joint comparison credit must retain computational time and factual derivatives. FT-Transformer and NODE already provide typed/neural-tree precedents. Our construction integrates the interface with temporal races, persistent addressed state and actual alternative credit. Current synthetic witness uses fixed predicates; no learned-threshold or real-tree benchmark advantage is claimed. The native hierarchy now learns useful lower-memory content in a 12-prefix FIT probe; frozen prior-centred readout gives 1.9258 vs prior 2.3694 NLL, 37.5% vs 16.7% accuracy. Erasing query contents removes the gain. Calibration is fitted/scored on the same FIT data; held-out part reuse is the next proof. 76 combined contracts pass. Source: hierarchy_development_evidence.json. Latest composition engineering: paired32-event/acquired-weight mechanism gate reduces native candidate scores11168→4000 and messages349→125; timer scores2→188. Different information paths, no equal-quality or total-FLOP claim. Separate observed-frame repair preserves world-pixel memory and removes pure-translation drift exactly with unchanged parameters; combined nuisance displacement.416184→.003158. First synthetic transfer fit fails at50%DEV accuracy; repaired128-update fit also50%DEV accuracy, TEST closed.76combinedcontracts pass. Source: hierarchy_development_evidence.json.

- [R5: Typed semantics, race composition and39mathematical/interface contracts](../experiments/theory/TYPED_SEMANTICS_AND_RACE_COMPOSITION_20261006.md) — Derived restricted raw-affine obstruction, typed event composition, unit/category contracts and joint-time credit. Existing synthetic fixed-predicate integration retained; learned predicate discovery and real-tree comparisons are next tests.


## 18. Single pass: error versus training compute.

Each model sees the 10M training characters once. Lower and further left is better. Slide 2 adds multi-pass runs.

p32 / D4 credited: 2.371491 bpc, 7.243 estimated whole-fit TFLOPs, 108,875 parameters. Saved Transformer-256×2: 2.426909, 111.262 TFLOPs, 1,658,907 parameters. This gives 15.36× lower fitting arithmetic and 15.24× fewer parameters for this saved control, with 0.0554 lower bpc. The strong one-pass LSTM is 2.170597 at 20.306 TFLOPs. Best native p96 is 2.162463 at 58.648 TFLOPs. Tuned dense references at our exact budgets (validation-selected) and the 90M matched-compute runs are running.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.


## 19. Start with low-batch language inference on existing hardware.

Product hypothesis for local and on-premise text applications; no customer interest reported yet.

This is a product hypothesis chosen to make the research investable and testable, not a confirmed customer need. The present character-language fits do not establish a production-quality token model, application task performance or persistent cross-request serving. Low-batch inference is a proposed test venue for stateful sparse execution, not a measured region of advantage. Use protocol-matched published references and saved checkpoints; spend new fitting on integrated native models; include setup, memory, warmup, traffic, latency and energy. The ≥20% threshold is a proposed economic screen, not a forecast. No customer interest has been reported; demand interviews and evaluation partners remain future work.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 20. Software proves the advantage. Hardware multiplies it.

One research program, with staged routes to deployment.

Hardware is a multiplier on the software result, applied to different parts of the energy budget. Largest lever: memory locality and sparse activity (DRAM read ~640 pJ vs ~3.7 pJ float multiply at 45 nm, Horowitz 2014); dense low-batch inference streams all weights per token, our model reads a few local state slots per event. Clock removal adds: no clock-tree power, average-case latency, near-threshold voltage tolerance, leakage-only idle capacity, and thermal headroom for memory-on-logic stacking and modular chiplets. Training locally is plausible (route credit and delay/gate updates are local) but the current trainer uses non-local backprop and clipping; a local learning rule is a milestone. Event-driven, memory-local chips exist (Loihi 2 and others); the field lacks a competitive trainable model, which is our licensing opening. No Sleeping Machines chip or joule measurement exists; baselines for hardware claims are competent clock-gated, SRAM-heavy synchronous designs as well as GPUs. Details: HARDWARE_THESIS.md.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.

- [H1: M. Horowitz — Computing's energy problem (and what we can do about it), ISSCC 2014](https://doi.org/10.1109/ISSCC.2014.6757323) — 45 nm per-operation energies: 32-bit DRAM read ~640 pJ, small SRAM read ~5 pJ, 32-bit float multiply ~3.7 pJ. Context for data-movement cost, not a Sleeping Machines measurement.

- [H3: Private hardware thesis (4 October 2026)](HARDWARE_THESIS.md) — Mechanism analysis of clockless, event-driven, memory-local execution; no chip or joule measurement.


## 21. A useful alternative could strengthen a hardware ecosystem.

Potential evaluation and licensing routes; no partner interest or relationship is claimed.

AMD is the strongest identified public fit precedent, not a presumed buyer. Its Ventures page lists Series A–C focus, so a €3M research-stage round may need angels/specialist deep-tech leads before strategic institutional investment. Intel’s system is a research prototype; Google has substantial internal alternatives and could build rather than license. Possible routes are benchmark collaboration, co-development, licensing, investment or eventual acquisition; none is a current pipeline asset. No company logos or implied endorsements are used.

- [S1: AMD — Silo AI acquisition completion, 12 August 2024](https://www.amd.com/en/newsroom/press-releases/2024-8-12-amd-completes-acquisition-of-silo-ai-to-accelerate.html) — Announced approximately $665M all-cash acquisition; Poro and Viking on AMD. Mature-team strategic precedent, not a pre-seed valuation comparable.

- [S5: Intel — Hala Point research system, 17 April 2024](https://www.intel.com/content/www/us/en/newsroom/news/intel-builds-worlds-largest-neuromorphic-system.html) — Loihi 2 neuromorphic research prototype, event computing and prospective continuous learning. No Intel interest in this project claimed.

- [S6: Google — Eighth-generation TPU architecture announcement](https://blog.google/innovation-and-ai/infrastructure-and-cloud/google-cloud/eighth-generation-tpu-agentic-era/) — TPU 8t/8i, model–hardware co-design and sparse MoE infrastructure. Existing internal capability creates both potential fit and competition.


## 22. Price the runtime against verified customer value.

Illustrative annual license economics; assumptions to test with an evaluation partner.

This example brings the commercial argument to an auditable customer denominator rather than treating global electricity, capex or subscriber counts as company TAM. All amounts are annual EUR. €1M eligible workload spend × 20% reduction = €200k gross saving; a 20% capture yields a €40k annual license and €160k buyer benefit before migration and other costs. Twenty-five equivalent licenses produce €1M annual revenue. None of these assumptions is established by current FLOP estimates or customers. Customer-count, scope, quality, reliability and adoption must be validated. This replaces the main-deck €1B spend/100M devices illustration; platform-scale scenarios remain explicitly hypothetical in the appendix.


## 23. AI research and software architecture in one founder.

Tero Keski-Valkama · Sole founder · Public career and invention record.

The XING timeline lists Cybercom December 2012–June 2018, HERE July 2018–April 2022, Alloy May 2022–August 2023, and Kaiko September 2023–December 2025. The founder’s portfolio lists Sleeping Machines and FAS Simulator. The published patent record (Google Patents, all publications, checked 7 October 2026) names Tero Juhani Keski-Valkama as inventor or co-inventor on 35 US and EP patent documents with priority dates from 2019 and publications through October 2025, all assigned to HERE Global B.V.; for example EP4148389A2 (maps from geospatial observations). The record supports sustained invention experience; these patents belong to the former employer and are not assets of this venture. Public personal biography and university links have availability/staleness issues; no degree or current-employment claim is inferred from them. Founder availability and references remain diligence items.

- [F1: Tero Keski-Valkama — public professional timeline](https://www.xing.com/profile/Tero_KeskiValkama) — Self-reported historical roles: Cybercom, HERE, Alloy.ai, Kaiko.ai. Dates and current commitment require founder confirmation.

- [F2: Patent record — Google Patents inventor search (all publications)](https://patents.google.com/?inventor=Keski-Valkama&dups=language) — 35 published US and EP patent documents name Tero Juhani Keski-Valkama as inventor or co-inventor (priority 2019 onward; publications through October 2025); assignee HERE Global B.V. Experience evidence, not Sleeping Machines-owned IP.

- [F3: Tero Keski-Valkama — public project portfolio](https://keskival.github.io/) — Self-published portfolio lists Sleeping Machines and FAS Simulator; project access may have changed. Sole-founder status supplied by founder.


## 24. Build defensibility across the model and its execution.

The strongest potential asset is an integrated stack that is difficult to reproduce and deploy.

Tero instructed on 3 October 2026 that the GitHub repository was made private. This deck is a local private artifact and no public publication is authorized. Earlier public disclosure cannot be undone by repository privacy. README credits Tero Keski-Valkama and Karoliina Salminen as research authors; sole-founder status does not establish sole authorship, inventorship or IP ownership. Contributor agreements, intended licenses and employment-related rights must be resolved before presenting an exclusive technology asset. No granted patent portfolio, customer integration or defensible legal monopoly is claimed. The founder confirms that his earlier patents are employer-owned, not venture assets. IP_PROTECTION_PLAN.md makes protection a financing deliverable: ownership/disclosure inventory, counsel-led prior-art and patentability review, selective priority filings and confidential implementation know-how. No candidate is represented as patentable or filed. Review earlier disclosures before further release; privacy does not restore novelty.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.

- [F2: Patent record — Google Patents inventor search (all publications)](https://patents.google.com/?inventor=Keski-Valkama&dups=language) — 35 published US and EP patent documents name Tero Juhani Keski-Valkama as inventor or co-inventor (priority 2019 onward; publications through October 2025); assignee HERE Global B.V. Experience evidence, not Sleeping Machines-owned IP.


## 25. Three gates determine whether this becomes a business.

Each gate has a falsifiable result and a consequence for further spending.

The principal investor risks are scalable prediction quality, economical execution and commercial adoption. Technical gaps include the trained float32 sparse-backend contract, longer memory/credit horizons, stable adaptation and hardware timing/precision. Corporate rights, team hiring and founder availability remain diligence items. The program preserves its architectural thesis while allowing a narrower viable product. No probability of success is assigned to these gates, and the €50M proposal is not inferred from benchmark scores. Execution priorities and owner admission paths are in INVESTOR_PROOF_PLAN.md. Its first priorities are replicated integrated quality, trained sparse execution and delayed memory-credit fidelity. The proposed ≥20% complete serving-cost improvement is a future commercial gate to lock before measurement, not an observed benefit. The AGI expansion proof is downstream of these technical gates. Hierarchy update15October: language L2/L4/L8 development NLL 5.9572/5.8987/5.8741, same slice and unique corpus, five/six/six epochs, one seed. Quality gain; work differs. Native eight-level/32-stage composition learns useful memory contents on FIT; calibrated 1.9258 vs prior 2.3694 NLL, 37.5% vs 16.7% accuracy. Same-data calibration, no held-out transfer claim. 76 combined contracts pass. Next: held-out part combinations and training-only calibration. Source: hierarchy_development_evidence.json.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 26. The next 18 months produce evidence investors can underwrite.

Proposed milestones measured from funding; spending advances with completed gates.

The timing is a planning assumption measured from funding. Three seeds and tuned modern controls are validation targets, not present assets. The ≥20% complete-cost gate is a proposed commercial screen and should be adapted to actual service requirements before experiments. Model quality and resource accounting must stay jointly comparable. Current owner queues retain priority; no new training or unguarded compute is launched to prepare this deck. Continued funding depends on completed results, measurable economics and a credible next workload rather than predictions entered as benchmark evidence. The immediate autonomous work sequence and current evidence gaps are documented in INVESTOR_PROOF_PLAN.md; timeline estimates do not substitute for gates or physical-host admission. Include useful representational hierarchy in the quality gate: retained lower-level memories, complementary child-role selection and relational refinement are implemented; unfamiliar-arrangement generalization remains a future measured result.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 27. €3M funds an 18-month research and engineering program.

Team, staged compute, hardware feasibility and IP protection, including selective patent filings.

The proposed allocation totals exactly €3M: team €1.35M, compute/replication €0.90M, hardware feasibility/measurement €0.25M, legal/IP/operations €0.20M, reserve €0.30M. Average six FTE × €150k/year fully loaded × 1.5 years equals €1.35M; this is a staffing assumption, not an actual hiring plan or salary survey. Operating burn excludes reserve; total budget consumption would average about €166.7k/month over 18 months if reserve is spent. Stage compute purchases by quality/system gates. Allocate founder plus representation/credit, systems/compiler, evaluation and hardware-measurement skills; exact staffing mix and ramp remain open. The existing €0.20M legal/IP/operations envelope explicitly includes IP inventory, counsel review, selective patent priority filings and staged prosecution alongside corporate/operating needs. Obtain counsel quotes before dividing this shared envelope; it is not €0.20M earmarked solely for patents, and no number of filings or grant timeline is promised. See IP_PROTECTION_PLAN.md. The founder’s earlier employer-owned patents are excluded from company assets. Commercially useful company-owned rights can strengthen defensibility; filing alone does not establish valuation uplift.


## 28. Raise €3M to establish a commercially valuable platform.

Proposed priced round; terms remain subject to company formation and investor diligence.

€3M at €50M priced pre-money yields €53M post-money and 5.6604% initial ownership before option-pool changes, fees, preferences and subsequent financing. This is a proposed negotiating price, not an independent appraisal, market-clearing estimate or investor offer. The main pitch explains the use of capital and proof points; it does not use arbitrary success odds to establish price. The appendix preserves transparent sensitivity arithmetic for investor discussion. A small ownership stake at a premium research-stage price may narrow the compatible investor pool; the round structure and lead investor fit are open commercial questions. The current VALUATION_RATIONALE.md explains ambition, potential assets and execution separately: coherent family design; value-credit and capacity mechanism evidence; completed restricted 90M learning; source-bound contracts and relevant founder experience. Further applications remain correlated hypotheses. A premium can fund transformative research before revenue, but breadth does not establish a market-clearing valuation. €100M remains a stretch scenario. Retain research co-author credit and resolve ownership; the financing plan adds complementary learning, runtime and evaluation capacity.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.

- [F1: Tero Keski-Valkama — public professional timeline](https://www.xing.com/profile/Tero_KeskiValkama) — Self-reported historical roles: Cybercom, HERE, Alloy.ai, Kaiko.ai. Dates and current commitment require founder confirmation.

- [F2: Patent record — Google Patents inventor search (all publications)](https://patents.google.com/?inventor=Keski-Valkama&dups=language) — 35 published US and EP patent documents name Tero Juhani Keski-Valkama as inventor or co-inventor (priority 2019 onward; publications through October 2025); assignee HERE Global B.V. Experience evidence, not Sleeping Machines-owned IP.


## 29. Build the model. Prove the economics. Open the hardware path.

€3M proposed raise · €50M proposed pre-money · Private investor discussion.

Requested financing is €3M. The financing purpose is an aggressive but gated increase in experiment throughput and engineering capacity. The key next investor asset is replicated quality plus a measured service-level advantage; a clockless-chip thesis adds upside after mapping is credible. This private deck includes an appendix for diligence rather than presenting pending work as completed. Contact details, company identity, jurisdiction, cap table and legal terms should be supplied by the founder before distribution. No outbound messages or public release were made.


## 30. The same model improves when unchosen paths receive credit.

Controlled small-model comparison; held-out error and estimated complete training work.

The local linearized credit estimator adds a derivative pathway for alternative delivered values while preserving the forward winner. It is not the exact full counterfactual trajectory gradient. The paired p32 / D4 T256 gain is 0.134895 bpc, with 0.3034% extra whole-fit estimated operations. The corresponding p32 / D8 gain is 0.130367. Attribution is stronger than a comparison between different widths, but a single seed still leaves variance and hyperparameter sensitivity unresolved.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 31. More available state. The same eight selected writes.

Small model with alternative credit: available memory doubles; selected updates stay fixed.

Pool 2 → 4 changes memory scalars from 512 to 1,024 and parameters from 108,875 to 177,019. At T256, quality changes from 2.371491 to 2.345157. Selected writes remain eight per input position; candidate keys increase 16 → 32. Winner-only per-position arithmetic increases 0.6576%, but whole-fit estimated work rises 64.9917%. All memory and key scoring still cost resources. A negative uncredited pool expansion was measured at D8, while this positive credited pair is D4; this is not a full matched 2×2 interaction test.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.


## 32. The sparse path is implemented; system proof is next.

Inference arithmetic per predicted character. Green bars: our implemented sparse runtime, which computes only the selected paths.

Small random float64 fixtures match full-emulator logits within roughly 1e-10. Actual trained float32 winner/state/cache parity and a full held-out rescore are prepared and pending. The prepared CPU worker retains prepacked matrices per fixed model version, but native admission remains unrun. Candidate key scans, copying, residency, setup, gather traffic, cache invalidation and quality must all be included in serving comparisons. The deck deliberately does not attach the trained quality to an unverified production backend or convert FLOPs to joules.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 33. An adaptation signal exists. Its work is accounted for.

Predict-before-update experiment on a new text stream; separate from the latest model family.

Frozen versus online evaluation scores 8,191 targets with predict-before-update, 16-character delayed-feedback blocks, lr 1e-4, fresh Adam, clipping and full-backbone gradients. Both arms retain persistent local state. BPC improves by 0.095120; total processing-operation estimates increase from 210,902,697 to 2,264,163,359, a 10.7356× ratio. This supports trainability under adaptation, not inexpensive lifelong learning. Retention, drift, long-horizon memory and local asynchronous learning need new evidence. Loihi 2 already provides an on-chip learning precedent.

- [R2: Private online-learning experiment, 8,191 targets](pitch_deck_evidence_20261003.json) — Predict-before-update pilot: quality and complete processing-operation estimates; one checkpoint, stream and learning rate.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 34. One substrate can support new communication and learning patterns.

Application hypotheses with first proofs; no codec, embodied-transfer or AGI result yet. The first row needs no special hardware.

The register in report/model_family_opportunities.md records six opportunities, mechanisms, evidence status, primary precedents and proof conditions. Dense arithmetic does not inherently require regularized input; variable-rate codecs and joint VLA models already exist. Our opportunity is coherent temporal/selective integration. Quantized message streams need a real wire/decoder contract; metadata/timing/reset and all endpoint work count. Joint motor/cognitive training needs shared information/credit and measured transfer; it does not prove AGI. Proposed application breadth supports platform optionality, not summed TAM or independent success chances. Existing integrated research queues retain priority.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 35. The contribution is the complete construction.

Established alternatives already address parts of this problem; they remain essential controls.

The pitch does not assert sole invention of sparse activation, gating, normalization, key/value separation or hardware learning. It proposes an integrated trainable temporal substrate and evaluates consequences. The latest native language model has no dense carrier or n-gram count component, but remains a restricted software realization. A weak result in one restricted variant should be diagnosed; genuine superiority requires matched strong controls. Intel Loihi 2 is cited on the adaptation and strategic slides.

- [T1: Vaswani et al. — Attention Is All You Need](https://arxiv.org/abs/1706.03762) — Primary architecture reference. The deck’s small saved control is not a frontier-performance claim.

- [T2: Fedus et al. — Switch Transformers](https://arxiv.org/abs/2101.03961) — Capacity beyond selected computation has established MoE precedent; sparsity alone is not a novelty claim.

- [T3: Gu and Dao — Mamba](https://arxiv.org/abs/2312.00752) — Selective recurrent state-space sequence models are relevant competitive controls. No matched modern SSM result is claimed.


## 36. What clockless, memory-local silicon can buy.

Physical mechanisms, their basis and what must be measured. No chip exists yet.

Mechanisms with physical bases, not measurements. Dense models can also use SRAM-heavy or near-memory chips, and MoE partially decouples capacity from activity; our edge is the model's sparse, local access pattern, which must hold at competitive quality (P0-6 tuned baselines). Race logic (ISCA 2014) is prior art for first-arrival computation. Full analysis: HARDWARE_THESIS.md.

- [H1: M. Horowitz — Computing's energy problem (and what we can do about it), ISSCC 2014](https://doi.org/10.1109/ISSCC.2014.6757323) — 45 nm per-operation energies: 32-bit DRAM read ~640 pJ, small SRAM read ~5 pJ, 32-bit float multiply ~3.7 pJ. Context for data-movement cost, not a Sleeping Machines measurement.

- [H2: A. Madhavan, T. Sherwood, D. Strukov — Race logic, ISCA 2014](https://doi.org/10.1109/ISCA.2014.6853226) — Prior art for delay-coded, first-arrival computation in hardware. We build on this primitive; it is not our invention.

- [H3: Private hardware thesis (4 October 2026)](HARDWARE_THESIS.md) — Mechanism analysis of clockless, event-driven, memory-local execution; no chip or joule measurement.


## 37. AMD’s Silo AI deal supports the strategic logic.

Announced approximately $665M all-cash acquisition in 2024; a mature-company precedent.

AMD’s announcement connects the acquisition to end-to-end AI solutions, engineering expertise, enterprise customers and Poro/Viking model work using AMD platforms, including LUMI. It does not establish that chip usage alone caused the acquisition. Silo had a large team and existing customers; neither applies here. The approximately $665M announced transaction value and Liquid AI’s $250M Series A amount are different quantities and are not converted into our pre-money valuation. They demonstrate strategic precedent, not an offer, floor or near-term acquisition expectation.

- [S1: AMD — Silo AI acquisition completion, 12 August 2024](https://www.amd.com/en/newsroom/press-releases/2024-8-12-amd-completes-acquisition-of-silo-ai-to-accelerate.html) — Announced approximately $665M all-cash acquisition; Poro and Viking on AMD. Mature-team strategic precedent, not a pre-seed valuation comparable.

- [S2: AMD — Acquisition announcement and LUMI collaboration, 10 July 2024](https://www.amd.com/en/newsroom/press-releases/2024-7-10-amd-to-acquire-silo-ai-to-expand-enterprise-ai-sol.html) — AMD highlighted enterprise solutions, expertise, software and Poro/Viking training on LUMI using AMD hardware; no single exclusive acquisition cause established.

- [S3: Liquid AI — $250M Series A announcement, 13 December 2024](https://www.liquid.ai/blog/we-raised-250m-to-scale-capable-and-efficient-general-purpose-ai) — Financing announcement and AMD collaboration on efficient models; funding amount is not a disclosed company valuation.


## 38. The constraints reach from power grids to robot batteries.

Economic context for efficient intelligence; these figures are not our revenue market.

IEA projects all datacenter electricity, not only AI demand; GSMA subscribers are not annual device shipments; IFR reports industrial-robot installed stock, not all robotics. These denominators cannot be summed into a TAM. The thesis is an inference about potential demand for verified efficient computation. Incumbents are also improving rapidly, which raises the threshold for a commercially useful alternative.

- [M1: IEA — Key Questions on Energy and AI, executive summary](https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary) — 485 TWh datacenter electricity in 2025; central projection 950 TWh in 2030. Sector context, not addressable revenue.

- [M2: GSMA — The Mobile Economy 2026](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-economy/wp-content/uploads/2026/02/The-Mobile-Economy-2026.pdf) — 5.8 billion unique mobile subscribers and 8.8 billion connections. Subscribers are not annual device sales or customers.

- [M3: IFR — World Robotics 2026 release, 24 September 2026](https://ifr.org/ifr-press-releases/news/five-million-robots-now-operate-in-factories-globally) — 5 million operating industrial robots in 2025 and more than 600,000 annual installations; no adoption by this project.


## 39. Successful platform adoption can support very large outcomes.

Conditional commercial arithmetic illustrates the scale required; no forecast or market multiple claim.

The €10B/€50B equity scenarios use deliberately stated revenue multiples rather than observed comparables. They require economics, durable margins and value capture that are wholly unproven. Multiplying revenue by a selected multiple is not an enterprise/equity reconciliation: the examples assume negligible net debt at exit. The scenarios overlap and are alternatives, not additive. Infrastructure relevance can justify funding risky research, but cannot itself prove a current valuation. Smaller niche success, delayed commercialization, licensing-only outcomes, further dilution and total failure remain possible.


## 40. The completed comparisons, using consistent resource units.

Frozen 10M-character, one-pass evidence. Model definitions are on the next slide.

All fitting columns include estimated complete step arithmetic rather than forward-only model FLOPs. Native representative operator traces include backward, alternative credit, clipping and Adam; dense controls use shape formulas with backward approximately twice forward. Inference includes traced unit and special-function arithmetic, but not DRAM traffic, copying, allocation, RNG, evaluation overhead or physical energy. Formula conventions differ and are stated. Per-position columns use one shared denominator type per column. Winner-only arithmetic is explicitly separated from emulator quality. Full CSV contains all 13 native fits and both controls.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.


## 41. Plain-language labels map to reproducible model records.

Message width counts scalars; available memory counts local state slots.

These names are editorial labels for the frozen completed configurations, not new models, products or a production-version series. Each native configuration has two heads per layer. Selected writes per input position are eight at four layers and sixteen at eight layers. Available slots equal layers × heads × pool size. Credit means the local linearized alternative-value estimator. The small timing-only row and alternative-credit row share forward parameters and architecture. Full filenames, source/parent hashes, exact operation counts and seed/protocol fields are retained in the private evidence ledger.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.


## 42. The comparison boundaries are part of the evidence.

Maintain the original records and disclose what a result actually measures.

The native score pays overlap-window warmup, evaluating roughly twice as many input positions as scored targets at T256. LSTM recurrent evaluation is a different protocol. Native T256 coverage is 999,936 targets, while original saved controls have a slightly different tail. The raw difference is small but must be disclosed. The frozen numerical ledger above covers 10M training. Separately, the current source-bound report records a completed 90M D4/P64/U2 value-credit evaluation: 1.857306 BPC on test[95M:96M], T256, 999,936 targets, one seed. Estimated whole fitting work is 241.219 TFLOPs, or 2.680 MFLOPs per fitting target presentation over 89,997,312 presentations. It changes data and width and is not the full official 5M test or a matched resource win. Checkpoints alone are not held-out results. Adaptive clock/stopping comparisons must preserve the declared query denominator and fallback, and charge attempted work; modeled time is not measured latency. No pending cells are filled with expectations. No additional Transformer or LSTM training is launched here; the user reserved it for AWS.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 43. Keep the failures beside the positive mechanism results.

A disciplined research program should revise interpretations when evidence changes.

D8 uncredited pool 2 scores 2.4565 and pool 4 2.4981 at T256. The D4 credited pool pair is distinct and should not be sold as a fully matched interaction. Normalized read/write credit gives 2.3840 versus read-credit 2.3715; other write-credit variants diverge and are retained historically. Best p96 quality gains over LSTM with more work. DVS small screens suggested lower coarsening work, but the full all-seed quality gate failed and the strong RBF control remains better. Target-dependent E63/E79 mixtures are quarantined for leakage and never used in this deck.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.

- [R3: Architecture, numerical contracts and report](../report/sleeping_machines_status.pdf) — Private technical report: whole-family definition, landscape, composition and scoped evidence. Modern matched controls, trained sparse parity and measured hardware energy remain open.


## 44. Reverse-underwriting shows the assumptions behind a price.

This arithmetic is a sensitivity tool; the research does not estimate platform-success probabilities.

The illustrative model discounts the retained fraction of a successful future equity outcome to today and assigns zero failure value. It is not a complete corporate DCF, does not model all cash flows, and assumes the retained cohort benefits from an exit equity value after future financing. €10B exit × 30% retention / 1.15^10 is the conditional present value; €50M requires 6.7426% and €100M requires 13.4852%. These are neither forecasts nor inferred from small benchmarks. A €3M priced round at €50M pre-money gives 5.6604% initial investor ownership before option-pool changes, fees, preferences or future rounds; at €100M it gives 2.9126%. An investor must independently accept technology scalability, commercial value capture, rights and execution to support a premium price.


## 45. The price depends on dilution, exit scale and time.

Required platform-success odds at 10 years and 15% discount; zero failure value.

This table is generated from the frozen financial model, not entered by hand. At a €3B outcome and 10% retained equity, the required probabilities are much higher than at a €30B exit with 50% retention. A lower discount rate increases the present value, while delays and dilution reduce it. In the €3M/€50M round, an investor retains 1.6981% at exit if 30% of its initial stake survives, giving €169.81M or 56.60× gross MOIC in the assumed €10B success outcome. That conditional upside is not expected return; failure is zero and cash-flow timing/preferences are omitted.


## 46. A private evidence pack and primary external context.

Source labels in slide footers are clickable; companion files must travel with the PDF.

Raw research evidence is private, per founder instruction. Original completed result SHA256 hashes are in pitch_deck_evidence_20261003.json. The status PDF contains detailed theory and historical evidence; do not treat invalid-protocol archives or old rendered report scores as active claims. Market sources were accessed on 3 October 2026. These external sector denominators support relevance, not customer intent or a venture revenue forecast.


## 47. Public precedents establish relevance, not endorsement.

Historical roles are self-reported; inventorship is checked against the published patent record.

The founder profile and portfolio are linked from the founder slide (F1, F3). Transformer and Mamba references are linked from the competition slide. The private diligence checklist remains open: corporate entity, cap table, founder commitment, contribution chain including Karoliina Salminen, employer invention assignments, licenses, compute/hiring quotes, trained backend admission, replication and measured service advantage. A private repository does not rescind earlier disclosures or itself establish patentability. No permission to distribute or contact potential partners is inferred from preparing this deck.


## 48. Prior event-driven language models.

Summaries of each paper's own claims; datasets, scales and compute conventions differ from ours.




## 49. The language experiments establish three useful facts.

Wikipedia text (text8), 10M characters of training. Prediction error in bits per character: lower is better.

T256 test values come from completed held-out evaluations; training scores are excluded. This frozen numerical comparison is the 10M experiment; the completed larger-data result is separately scoped in the protocol appendix and current report. One nominal pass uses about 9.994M training positions. A single seed and differing native/control training order limit generalization. The p96 improvement over LSTM is 0.0081 bpc, with 2.89 times fitting work; this one-pass row is a quality win at higher training compute; the matched-compute wins (slide 2) use the multi-pass and wider rows.

- [R1: Private completed language evidence ledger (3 October 2026)](pitch_deck_benchmarks.csv) — Saved native fits and E64 controls. Original JSON records and SHA256 hashes are supplied in the private diligence pack.


## Reproduce and inspect

The editable slide narrative is PITCH_DECK.json. The frozen parent hashes, exact derived metrics and assumptions are in pitch_deck_evidence_20261003.json. CSV exports use identical column units for every model. Run the preparation only when deliberately updating the evidence cut-off; use a fresh publication tag to render. This build imports no numerical model runtime.


Open diligence: company/jurisdiction, cap table and option pool; founder availability; contribution and IP chain of title (including credited co-author Karoliina Salminen); employer invention assignments; intended software/model licenses; budget quotes; fresh held-out prediction per total learning cost; trained sparse-backend parity; measured system energy/traffic; design-partner willingness to pay. No contacts have been made by this work.
