# Battle B1 — EasyTPP temporal point processes

Owner: AWS host session (6 October 2026). Orders: PRODUCT_ORDERS.md. Attempt level: **in development**.

## Frozen protocol (matches the published leaderboard)

- Data: the HuggingFace EasyTPP releases `easytpp/{amazon,retweet,taxi,taobao,stackoverflow}`, default train/dev/test
  splits, used as released (`data/easytpp/`). Statistics match S2P2/HHP Table 7/4.
- Primary metric: per-event total log-likelihood in nats on TEST, as computed by the S2P2 fork of EasyTPP
  (`UCIDataLab/state_space_point_process`, commit c3933240): for every sequence, events 2..N are scored with
  log λ_{k_i}(t_i) minus the compensator ∫ λ over (t_{i-1}, t_i]; no term after the last event; the sum over the test set
  is divided by the number of scored events. Their compensator is a 10-point Monte Carlo estimate; ours is exact
  wherever the model admits it (same quantity, no estimator noise).
- Decomposition: time LL = log λ(t_i) − compensator; mark LL = log λ_{k_i}(t_i) − log λ(t_i) (mark given true time).
- Secondary: next-event time RMSE (expected next time, Mei & Eisner) and next-mark accuracy given the true time.
- Selection: early stopping and model choice on DEV only; TEST is scored once per selected configuration and seed.
  Five seeds for any reported number, matching the references.

## Published references (S2P2, NeurIPS 2025, Table 8; 5 seeds; nats per event)

| Model | Amazon | Retweet | Taxi | Taobao | StackOverflow |
|---|---:|---:|---:|---:|---:|
| RMTPP | −2.136 | −7.098 | 0.346 | 1.003 | −2.480 |
| SAHP | −2.074 | −6.708 | 0.298 | 1.168 | −2.341 |
| THP | −2.096 | −6.659 | 0.372 | 0.790 | −2.338 |
| IFTPP | 0.496 | −10.344 | 0.453 | **1.318** | −2.233 |
| MHP | −2.091 | −6.564 | 0.370 | 0.636 | −2.346 |
| NHP | 0.129 | **−6.348** | 0.514 | 1.157 | −2.241 |
| AttNHP | 0.484 | −6.499 | 0.493 | 1.259 | −2.194 |
| S2P2 | **0.781** | −6.365 | **0.522** | 1.304 | **−2.163** |
| HHP (Boyd et al., 2025) | 0.603 | −6.357 | 0.522 | 1.273 | −2.195 |

Best time LL: Amazon 2.652 (S2P2), Retweet −5.584 (NHP), Taxi 0.735 (IFTPP), Taobao 2.719 (S2P2), StackOverflow −0.641
(S2P2). Best mark LL: Amazon −1.871 (S2P2), Retweet −0.764 (NHP), Taxi −0.211 (S2P2), Taobao −1.391 (IFTPP),
StackOverflow −1.510 (AttNHP). Seed standard deviations are 0.002–0.04 on most cells (Taobao S2P2 0.039).
Model sizes are small: HHP uses 5K–24K parameters on these datasets.

Sources: [S2P2](https://arxiv.org/abs/2412.19634), [HHP](https://arxiv.org/abs/2511.01096),
[EasyTPP](https://arxiv.org/abs/2307.08097).

## Task study (`experiments/tpp/data_study.py`; counting only)

| Dataset | Structure | Simple count model vs best published mark LL |
|---|---|---|
| Amazon | Gaps sharply bimodal: ~10% near 0.011, most in 0.72–0.80 (max 0.8). Next mark in last five 61%. | prev mark + gap bin −2.099 vs −1.871 |
| Retweet | Integer seconds, 4.2% zero gaps, heavy tail (median 40 s, p99 63,000 s); log-gap autocorrelation 0.44 | −0.822 vs −0.764 |
| Taxi | Pickup/dropoff alternate: next mark never equals previous; gap informs the mark | −0.237 vs −0.211 |
| Taobao | Strong repetition: next equals previous 60% | prev 2 marks −1.484 vs −1.391 |
| StackOverflow | 22 badges, weak first-order structure; 0.5% zero gaps | −1.710 vs −1.510 |

S2P2's lead over other models comes mainly from time LL. Time densities on Amazon and Taobao are sharp and multimodal;
zero gaps on Retweet and StackOverflow require positive hazard at zero elapsed time.

## Design rationale: a race of delayed clocks over persistent temporal memory

The family's core primitive is the output distribution itself. After each event, M latent clocks start. Each clock m has a
history-dependent firing-time distribution (exponential, for hazard at zero elapsed time, or log-normal, a learned delay
with learned dispersion) and its own mark distribution. The first clock to fire produces the next event. Then
- the total intensity is the sum of the clock hazards, λ(τ) = Σ_m h_m(τ), and the survival is the product of clock
  survivals, so the log-likelihood is exact and closed-form, with no Monte Carlo compensator;
- the marked intensity is λ_k(τ) = Σ_m h_m(τ) p_m(k): the mark distribution depends on elapsed time through which clock is
  likely to be winning — learned delays and races perform the computation;
- every losing clock receives exact counterfactual credit through the survival term (it is credited for not firing):
  credit to unrealized alternatives is analytic here, and silence until the event is supervised.

History enters through the family's persistent state: stacked layers of complex-diagonal memories that decay and rotate
with the real elapsed time between events, written by small messages that mix the event's content with memory, plus an
addressed mark memory — one slot per mark, written sparsely only when that mark occurs, decaying at learned rates, and
read through separate keys and values. The addressed bank gives every mark a Hawkes-like recency trace (capacity K
slots, one write per event) without forcing it through a small shared state.

What the leading models lack and this design adds: IFTPP has a flexible gap mixture but time-independent marks; S2P2 has
continuous-time linear state but a smooth intensity built from damped oscillations, which struggles with sharp delayed
peaks; neither has addressed per-mark memory.

## Development log

| Date | Iteration | Change | DEV result | Diagnosis / next |
|---|---|---|---|---|
| 6 Oct | contract | race_tpp numerical contract | density integral 1 − 3e−12; exact compensator = quadrature; Σ_k λ_k = λ | PASS |
| 6 Oct | r1 | default race clocks (d32, 16 modes, 2 layers, 2 exp + 4 log-normal clocks, dv4), early stop | Taxi 0.475 (time 0.707, mark −0.232); StackOverflow −2.203 (−0.735, −1.468); Taobao 1.249 (2.697, −1.448) | Overfits after ~25–50 epochs. Mark LL at count-model level on Taxi: time-conditional mark resolution limited to 6 clocks. StackOverflow time LL weakest. |
| 6 Oct | calibration | count models scored on DEV and TEST (`split_calibration.py`) | TEST − DEV offsets, total: Taxi +0.10, Taobao +0.12, Retweet +0.03, Amazon −0.01, StackOverflow −0.01 | DEV numbers are read against TEST references with these offsets; verdicts only from one TEST scoring of the selected config, 5 seeds |
| 6 Oct | r1 Amazon/Retweet | same | Amazon −0.229 (time 1.651, mark −1.880); Retweet −6.403 (−5.636, −0.767) | Amazon time far behind S2P2 (2.652): see gap analysis below |
| 6 Oct | analysis | Amazon gap histogram | 31% uniform on [0.010, 0.015], 69% uniform on [0.70, 0.80]; a two-box density alone is worth ≈ 2.61 nats | A race of always-firing clocks cannot put 69% of mass on the later box: the earliest clock almost always wins |
| 6 Oct | r2 (v3) | delayed clocks fire with learned probability π (silent routes), 8 log-normal clocks | Amazon **0.705** (2.585, −1.880); Taobao **1.281** (2.733, −1.453); Taxi **0.485** (0.712, −0.227); StackOverflow **−2.171** (−0.712, −1.459) | v3 improves all four; v3 is the B1 model. Small datasets peak at 13–35 epochs |
| 6 Oct | g0, g1 | long training, no early stop: no decay (g0); d64 + decay 0.1 (g1) | g0 best 0.475 at epoch 27, DEV 0.32 by epoch 589; g1 DEV 0.18 by epoch 209 and falling | no recovery yet; decay 0.1 at lr 3e−3 is too weak; g2 (decay 1.0) and g3 (asymmetric) pending |
| 6 Oct | r3 (v4) | Taxi regularization: dropout 0.3; weight EMA 0.999; EMA + d64 + decay 1.0, 600 epochs | 0.487; 0.484; 0.453 (train ≈ DEV, no memorization, lower plateau) | Regularization alone does not move Taxi past v3 (0.485); g2 (decay 1.0) also plateaus ≈ 0.453 by epoch 809; g3 (asymmetric private decay) pending |
| 6 Oct | r4 | Amazon, 16 delayed clocks | **0.720** (time 2.602, mark −1.881) | denser clock tiling helps box-shaped gaps; d64 variant and StackOverflow arms queued; Retweet v3 queued |

**Status (6 Oct ~16:30 UTC).** Estimated against published TEST bests using count-model split offsets (not a verdict):
ahead on Taxi and Taobao (time and mark), behind on Amazon time (≈0.06 after r4) and StackOverflow time (≈0.03),
near level on Retweet. Next: finish r4 and Retweet v3; per-dataset small grid as the references did; then one TEST
scoring of each selected configuration with 5 seeds; measure inference work.
| 6 Oct | r4 | wider state (d64, 32 modes) with 16 clocks; StackOverflow 16 clocks | Amazon d64 0.661 (vs 0.720 at d32); StackOverflow 16 clocks −2.178, d64 −2.188 (vs −2.171) | wider states overfit these small datasets; capacity is not the limit |
| 6 Oct | g1–g3 | long training with decay 0.1 / 1.0 / asymmetric private ×10 | best DEV all at early epochs (0.478, 0.460, g3 0.29 by epoch 133 and falling) | on these noisy event datasets long decayed training does not recover past early selection; recipe: v3 + DEV early selection |
| 6 Oct | r2 Retweet (v3) | defective delayed clocks on Retweet | DEV **−6.089** at epoch 20 and improving (time −5.315, mark −0.774), vs v1 −6.403 | ≈0.26 nats ahead of the best published TEST (NHP −6.348) before the +0.036 offset |
| 6 Oct | final Taxi | TEST protocol queued: v3, 8 delayed clocks, dropout 0.3; 5 seeds | pending | Taxi verdict |
| 6 Oct | r5 | dropout 0.3 on Taobao / Amazon (16 clocks) / StackOverflow | pending | last DEV round; then TEST protocol per dataset |
| 6 Oct | audit | grid audit (`grid_audit.py`): DEV scored as recorded and with gaps dequantized inside their recording cell | Retweet v3: −5.919 recorded vs **−6.632 dequantized** (drop 0.71; 37.5% of delayed clocks at the 0.005 dispersion floor); Taxi drop 0.000; Taobao 0.0001; StackOverflow 0.009 | **The Retweet DEV lead was an artifact of integer-second recording and is withdrawn.** Smooth intensity references cannot spike on grid points; ours must not either |
| 6 Oct | v5 | resolution floor: every delayed clock's spread at its delay is at least one recording cell, σ ≥ max(0.005, cell·e^(−μ)); cells from TRAIN: Retweet 1 s, Taxi 1 s (1/3600 h), StackOverflow 2⁻¹³, Taobao 10⁻⁴ (87% of gaps), Amazon none | contract PASS | all final protocols use v5 |
| 6 Oct | r5 | dropout 0.3 | Taobao 1.284 (vs 1.281); Amazon 16 clocks **0.724** (vs 0.720) | selected |
| 6 Oct | final | TEST protocols queued (v5, 5 seeds): Taxi, Taobao, Amazon; Retweet v5 development run | pending | |
| 6 Oct | r7, r8 | StackOverflow under the floor: 4 exp clocks −2.190, 16 clocks −2.187; v6 (time since sequence start) queued for StackOverflow and Amazon | — | the unfloored −2.166 partly exploited the 2⁻¹³ grid; StackOverflow ~0.035 behind |
| 6 Oct | final Taxi s0 | first TEST seed | **TEST 0.5250** (time 0.732, mark −0.207) vs S2P2 0.522 ± 0.004 | count-model split offsets overestimated TEST (predicted ≈0.58); no longer used — only TEST protocols decide |
| 6 Oct | resources | `work.py`: parameters / per-event MACs | S2P2 ÷ ours: Taxi 12.3× / 12.1×, Amazon 4.1× / 4.0×, Retweet 17.6× / 17.5×, Taobao 1.1×, StackOverflow 1.1× | |
| 6 Oct | ensemble (DEV) | predictive mixture of five Taxi members (`ensemble_eval.py`) | members 0.484–0.492, mixture **0.497** | |

**Pre-registered reporting rule (fixed 6 Oct before any 5-seed TEST aggregate was seen).** Each dataset reports (1) the
single-model TEST mean ± sd over its 5 protocol seeds and (2) the uniform predictive mixture of those 5 seeds on TEST,
with per-event inference MACs beside S2P2's. The mixture is a matched-compute (inference) comparison only where 5× our
MACs ≤ S2P2's (Taxi 0.41×, Retweet 0.29×) or within 10% (near-matched); elsewhere (Amazon 1.25×, Taobao 4.5×,
StackOverflow 4.6×) it is reported as a higher-compute result, not a matched win.
| 6 Oct | **final Taxi** | v5, 8 delayed clocks, dropout 0.3, floor 1 s; 5 seeds, TEST once per seed at best DEV | single model **0.5250 ± 0.0010** (time 0.733, mark −0.208) vs S2P2 0.522 ± 0.004; **5-seed mixture 0.5363** (time **0.740**, mark **−0.204**) | **WIN, confirmed (5 seeds).** The mixture beats every published model on total, time (best published 0.735, IFTPP) and mark (best −0.211) LL at 0.41× S2P2's per-event inference MACs; the single model leads on the mean at 1/12 of S2P2's parameters and per-event MACs |
| 6 Oct | StackOverflow selection | v5 base −2.175, 3 layers −2.173, v6 −2.179 (DEV) | selected v5 3 layers | TEST protocol queued |
| 6 Oct | **final Taobao** | v5, 8 delayed clocks, dropout 0.3, floor 10⁻⁴; 5 seeds | single model **1.3991 ± 0.0025** (time **2.753**, mark **−1.353**) vs best published 1.318 ± 0.017 (IFTPP), S2P2 1.304; 5-seed mixture 1.4173 (4.5× S2P2 MACs: higher-compute result) | **WIN, confirmed (5 seeds): +0.081 nats over the best published model**, best time and mark LL, at 0.92× S2P2's per-event MACs (24,362 vs 26,016). Grid audit drop 0.0002 (Taxi 0.0) |
| 6 Oct | **B1 pass criterion met** | best published LL on ≥ 2 of 5 datasets, 5 seeds | Taxi and Taobao | Amazon (v7 windows), StackOverflow and Retweet continue |
| 6 Oct | v7 | Kumaraswamy window clocks (hard edges) on Amazon | DEV 0.677 (vs v5 0.724) | hard window edges receive gradient only from events inside the window; dropped |
| 6 Oct | v8 | **logistic-window delayed clocks**: density ∝ σ((τ−a)/s) − σ((τ−b)/s), closed-form stable survival, learned edge scale; contract density integral 1 − 6e−11 | Amazon 16 delayed + 4 window clocks DEV **0.768** (time **2.645**, mark −1.877) vs v5 0.724 | windows close most of Amazon's time-shape loss (DEV bound analysis: exact two-box 2.639 history-free, 2.661 with history counts) |
| 6 Oct | final StackOverflow (v5) | 3 layers, 8 delayed clocks, dropout 0.3, floor 2⁻¹³; 5 seeds | single model −2.1809 ± 0.0055 (time −0.674, mark −1.506) vs S2P2 −2.163 ± 0.009; **5-seed mixture −2.154** (time −0.666, mark **−1.488**) | single model behind by 0.018 (time); **mixture is a pure-accuracy win at 4.6× S2P2's per-event MACs** (not compute-matched). v8 StackOverflow queued |
| 6 Oct | final Amazon (v5) | 16 clocks, dropout 0.3; seeds 0–2 | 0.7008 ± 0.0263 vs S2P2 0.781 | superseded by v8 (DEV +0.044); v8 TEST protocol next |
| 6 Oct | Retweet r10/r13 | d64 + 16 clocks (v7); v9 cascade age (8 delayed + 4 windows) | best DEV −6.396 / −6.391 (from training logs; both runs stopped by the 3 GB RSS watchdog during the final expected-time quadrature after training) | Retweet plateaus at ≈ −6.39 across v5/v7/v9 and width; remaining time gap to NHP not addressed by capacity, age or windows. Future Retweet runs: 9 GB cap |
| 6 Oct | final Amazon v8 s0 | 16 delayed + 4 window clocks | TEST **0.7682** (time 2.622, mark **−1.854**) vs S2P2 0.781 ± 0.011 | 0.013 behind; mark beats every published model; 3.5× fewer parameters/MACs than S2P2 |
| 6 Oct | StackOverflow v8 | windows, 3 layers | DEV −2.177 (v5 −2.173) | no gain: StackOverflow's time gap is not window shape; no periodicity in its times |
| 6 Oct | v10 | **continuous-time state clock**: a persistent complex memory keeps decaying and rotating through the silent interval and drives a hazard and a mark distribution (24-node Gauss–Legendre compensator; contract: density integral 0.99999 at 24 and 48 nodes) | Retweet DEV −6.252 at epoch 2 | **audit: artifact.** Dequantized DEV −6.485 (drop 0.23; 512-node compensator −6.518): learnable rotation frequencies produced hazard peaks on integer seconds. Run stopped, result withdrawn |
| 6 Oct | v12 | resolution floor extended to dynamics: with a recording cell, rotation frequency ≤ one period per 8 cells and decay rate ≤ one per cell; v11 clustered window initialization included | contract PASS | Retweet v12 queued; every state-clock result is audited (dequantized + 512-node compensator) before it counts |
| 6 Oct | v11 | windows initialized from 1-D k-means of TRAIN log gaps | queued (Amazon seeds 0, 1) | Amazon v8 seeds diverge (TEST 0.768 vs 0.736); quantile init placed a window between the two boxes |
| 6 Oct | v10 StackOverflow | state clock (16 modes), 3 layers, 8 delayed clocks, floor 2⁻¹³ | DEV **−2.143** (time **−0.688**, mark −1.455) vs v5 −2.173 | **audit clean**: dequantized drop 0.0001; 512-node compensator identical. A real continuous-time gain; StackOverflow v12 TEST protocol queued |
| 6 Oct | B3 admission | FAS v2 data, reference smokes, native C1/C2 admitted on slot 2 (user-directed) | — | |
| 6 Oct | **final StackOverflow (v12)** | state clock (16 modes), 3 layers, 8 delayed clocks, dropout 0.3, floor 2⁻¹³; 5 seeds | single model **−2.1444 ± 0.0037** (time −0.643, mark **−1.501**) vs S2P2 −2.163 ± 0.009; 5-seed mixture **−2.1113** (time **−0.633**, mark **−1.478**) | **WIN, confirmed (5 seeds): +0.019 nats over the best published model**, best mark LL, time level with the best; 1.26× S2P2's per-event MACs (36,732 vs 29,216): pure-accuracy win; matched-size (2-layer, 29,191 parameters) DEV check queued. Audit: dequantized drop −0.0002; 512-node compensator scores higher than the protocol's 24 nodes (reported numbers are conservative) |
| 6 Oct | Amazon | v10 state clock DEV 0.741 (1 seed); v8 TEST seeds 0.768 / 0.736 / 0.687 / … | — | Amazon's limit is optimization variance across seeds; v11 clustered-window initialization on 4 seeds running |
| 6 Oct | v12 Retweet | state clock with frequency/decay caps | DEV −6.246 (time −5.481) | **audit: artifact.** Dequantized drop 0.224 (floored v5 baseline 0.0006, so the audit is calibrated). Per-gap analysis: the entire loss is at zero gaps (4% of events: +0.626 recorded vs −4.688 dequantized) — a hazard spike at exactly τ = 0 scoring same-second events at an instant. Withdrawn |
| 6 Oct | v13 | below one recording cell the state clock's hazard and marks are held at their value at one cell; compensator λ(c)·min(τ, c) + ∫_c^τ λ | normalization 1 − 5e−10 with cell (mass below the check grid included); compensator = 400k-point quadrature to 1e−11 | Retweet v13 queued. StackOverflow's win is unaffected (cell 2⁻¹³, audit drop −0.0002) |
| 6 Oct | v11 Amazon | clustered window init, 4 seeds | DEV 0.691 / **0.797** / **0.798** / 0.742 (time up to 2.675) | higher ceiling, seed variance remains: optimization has distinct basins. Next: protocol seeds as best-of-3 restarts selected on DEV (3× training compute reported) |

**Pre-registered Amazon v11 protocol (fixed 6 Oct ~23:40 UTC, before any of its runs).** Configuration: v11, 16 delayed +
4 clustered-window clocks, dropout 0.3, patience 30. Protocol seed s ∈ {0..4} trains restarts with seeds s, s+100,
s+200; `b1_restart_select.py` keeps the restart with the best DEV LL and reports its TEST (selection never reads TEST).
Training compute is 3× a single fit; inference compute is unchanged (one selected model per protocol seed).
| 7 Oct | v13 Retweet | state clock held below one cell | DEV −6.326 (time −5.562) | **audit: not clean.** Dequantized drop 0.045 (baseline 0.0006): 0.031 at 1 s gaps (−1.764 recorded vs −2.276 dequantized) — rate caps bound the time scale but not the amplitude, so the hazard can still sharpen within a cell. Not counted |
| 7 Oct | v14 | uniform dequantization of TRAIN gaps within the recording cell each epoch (standard for density models of discretized data); evaluation unchanged on the protocol's raw data | Retweet queued | |
| 7 Oct | Amazon protocol (partial) | restart selection by DEV | seed 0: DEV picks 0.798 over 0.691 → TEST **0.798**; seed 1 → TEST 0.796 | above S2P2 0.781 so far; three seeds remaining |
| 7 Oct | v14 | dequantized whole TRAIN sequences | Retweet DEV −6.70 at epoch 4; stopped | design error: history inputs never contained exact zero gaps in training but do in DEV/TEST (input mismatch) |
| 7 Oct | v15 | dequantize only the scored target gap within its cell during training; history inputs stay as recorded | Retweet queued | |
| 7 Oct | v15 | target-only dequantization | Retweet DEV −6.61 after epoch 1; stopped | trained to put first-cell mass on delayed clocks, whose hazard at exactly τ = 0 is zero, so raw zero gaps score poorly |
| 7 Oct | v16 | resolution principle for every clock: hazards held at their one-cell value on [0, c), log S = −h(c)·min(τ, c) + [log S0(max(τ, c)) − log S0(c)] | normalization 1 − 4e−9 | Retweet v16 (with target dequantization) queued |
| 7 Oct | Amazon protocol (partial) | — | seeds 0–1 complete: TEST 0.7969 ± 0.0014 | seeds 2–4 restarts running |
| 7 Oct | estimator parity | all 15 final TEST models re-scored with the EasyTPP/S2P2-fork estimator (log λ_k at events minus a 10-point uniform Monte Carlo compensator per interval, as in `compute_loglikelihood`), 5 Monte Carlo repeats | Taxi 0.5244 (exact 0.5250); Taobao 1.3992 (1.3991); StackOverflow −2.1427 (−2.1444); per-model differences within Monte Carlo spread (sd 0.002–0.004) | the wins hold under the leaderboard's own computation (`b1_easytpp_estimator_check.json`) |
| 7 Oct | Amazon protocol (partial) | — | 3 complete seeds TEST 0.7964 ± 0.0013; seeds 3–4 so far only low-basin restarts (≈0.74 DEV) | final verdict when all 15 runs complete |
| 7 Oct | Amazon basin diagnosis | DEV time LL by gap box, high-basin (s0_r2) vs low-basin (s0_r0) restart | low box 4.246 vs 4.254 (uniform ideal 4.166); **upper box 1.928 vs 1.763** (ideal 1.914); P(low box) predicted 0.317 / 0.319 (actual 0.322) | the basin difference is entirely the shape fit of the [0.70, 0.80] box: three narrow clustered windows sometimes fail to tile it. v17: one logistic window per gap component separated by empty histogram bins (≥ 5% mass each), spares duplicate the largest; Amazon gets [0.0100, 0.0150] and [0.7005, 0.7995]; other datasets fall back to v11 tiling. Four-seed stability test queued |
| 7 Oct | **final Amazon (v11, pre-registered restart selection)** | 5 seeds × 3 restarts, DEV-only selection | TEST **0.7839 ± 0.0265** (time 2.639, mark **−1.855**) vs S2P2 0.781 ± 0.011; per-seed 0.798 / 0.796 / 0.795 / 0.794 / 0.737 | **Mean ahead at 0.29× S2P2's per-event compute, not a confirmed win**: seed 4's three restarts all landed in the low basin. Best mark LL published. v17 (one window per gap component) targets the basin |
| 7 Oct | Retweet v16 | every clock held below the 1 s cell + target dequantization | DEV **−6.352** (time −5.588, mark −0.764); audit drop **0.0038** (baseline 0.0006) | grid-safe within a small residual; +0.04 over floored clocks; TEST protocol queued (5 seeds) |
| 7 Oct | **final StackOverflow, matched size (v12, 2 layers)** | 29,191 parameters (S2P2 30,166), 29,660 MACs/event (S2P2 29,216 → 1.015×); 5 seeds | TEST **−2.1525 ± 0.0045**, every seed above S2P2 (−2.1577 … −2.1459) vs −2.163 ± 0.009; EasyTPP estimator −2.1509; audit −0.005 | **Near-matched-compute WIN, confirmed (all 5 seeds)** — satisfies the valuation condition "matched-compute wins on further EasyTPP datasets" |
| 7 Oct | v17 Amazon | one window per gap component, 4 seeds (3 done) | DEV 0.802 / 0.796 / **0.739** | basin less frequent, not gone. Diagnosis: in the low seed both upper-box windows drifted to ≈[1.1, 1.3], beyond every observed gap (good seed: one window exactly on [0.700, 0.800], fire prob 1.0) |
| 7 Oct | v18 | windows anchored to their gap component: start within ×e^±0.3, width within ×e^±0.5 of the data-derived init | contract PASS; 5 seeds queued | if all five seeds reach the high basin, a restart-free Amazon protocol follows |
| 7 Oct | **final Retweet (v16), 5 seeds, TEST** | pre-registered protocol: every clock held below the 1 s cell, target dequantization, best-DEV checkpoint, TEST once per seed | **−6.3262 ± 0.0009** (seeds −6.3272, −6.3261, −6.3250, −6.3270, −6.3256); time −5.558, mark −0.768 | **WIN** vs NHP −6.348 (+0.022) and S2P2 −6.365 (+0.039); all 5 seeds ahead; EasyTPP Monte Carlo estimator −6.3256 on seed 2 (exact −6.3250); grid-audit drop 0.0038; 19,654 parameters, 19,850 MACs/event vs S2P2 298,627 / 297,600 (15×). Fourth of five datasets won |

**Pre-registered Amazon v18 protocol (fixed 7 Oct 14:55 UTC, before any v18 TEST scoring; seeds 2–4 not yet
trained).** Configuration as queued in `b1_r24_amazon_v18_s{0..4}` (v18 anchored windows, 16 delayed clocks + 4 windows,
dropout 0.3, patience 30), one run per seed, **no restarts** (one third of the v11 protocol's training work). Each seed's
best-DEV checkpoint is scored **once** on TEST by `experiments/tpp/score_test.py`, which first rebuilds the model and
must reproduce the run's recorded DEV log-likelihood to 1e−9 (otherwise the scoring is void and the seed is rerun with
`--score-test`). The CPU fit is deterministic per seed, so this equals a fresh `--score-test` run of the same seed
without repeating its training. Report: TEST mean ± sd over the five seeds and every seed's value, whatever they are,
against S2P2 0.781 ± 0.011; a win requires the mean ahead; "all seeds ahead" is stated only if true. The v11 result
(0.7839 ± 0.0265) stays in the record.

| Date | Run | Change | Result | Reading |
|---|---|---|---|---|
| 7 Oct | **final Amazon (v18), pre-registered protocol, TEST** | anchored windows; one run per seed, no restarts; best-DEV checkpoints scored once by `score_test.py` (DEV reproduced exactly, |diff| 0 for all five) | **0.8028 ± 0.0007** (seeds 0.8032, 0.8021, 0.8030, 0.8022, 0.8036); time **2.657**, mark **−1.854** | **WIN** vs S2P2 0.781 ± 0.011 (+0.022), all 5 seeds ahead, best published time (2.652) and mark (−1.871); EasyTPP Monte Carlo estimator 0.8037–0.8060; no recording grid (281K distinct gaps); 35,000 parameters, 35,936 MACs/event vs S2P2 127,056 / 125,568 (0.29×). **All five EasyTPP datasets won** |
| 7 Oct | **v19 unified** | one driver with every mechanism of the five wins: defective delayed clocks, logistic windows anchored to their gap component with component-aware initialization (v17/v18), state clock, resolution principle for every clock with target-only dequantization (v16) | contracts PASS: density integral 1 − 5e−12 (no cell) and 1 − 5e−9 (cell 0.05); without a cell v19 reproduces the v18 Amazon checkpoint's DEV exactly (diff 0.0) | queued (DEV, seed 0): one configuration (8 delayed clocks, 4 windows, 16 state modes, dropout 0.3, patience 30) on all five datasets, only the recording cell differing (Taxi 1/3600, Taobao 1e−4, StackOverflow 2⁻¹³, Retweet 1, Amazon none). Decides whether a single model wins the whole benchmark |
| 8 Oct | v19 unified, DEV seed 0 (partial) | one configuration, 2 layers | Amazon **0.8031** (dedicated v18: 0.8042); StackOverflow **−2.1429** (dedicated 2-layer v12: −2.1569; 3-layer v12: −2.1386) | the unified model matches the dedicated ones: −0.001 on Amazon, +0.014 over the same-size StackOverflow model. Taxi running; Retweet and Taobao queued |
| 8 Oct | v19 unified, DEV seed 0 | Taxi | **0.4881** (dedicated v5: 0.4872) | three of three so far match or beat the dedicated models with one configuration; Retweet and Taobao queued |
| 8 Oct | v19 unified seeds 1–4 (queued) | Amazon, StackOverflow, Taxi; DEV only | — | development seeds so that, if Retweet and Taobao also hold, a five-seed TEST protocol can be pre-registered and scored from best-DEV checkpoints without retraining. No v19 checkpoint has been scored on TEST |
| 8 Oct | v19 unified seeds (DEV) | one configuration with 4 windows everywhere | Taxi 5 seeds: mean 0.4875 (dedicated v5 0.4872); StackOverflow seeds 0–3: mean −2.1471 (dedicated 2-layer −2.1482), **seed 4 −2.1785** (time LL −0.724 vs −0.69 for the others; mark LL normal) | the windows add a weaker timing basin on a single-humped gap distribution |
| 8 Oct | **window rule (data-derived)** | logistic windows only when the TRAIN gap histogram separates into ≥ 2 components of ≥ 5% each (the same detector that places windows on components) | Amazon 2 (31% / 69%), Retweet 2 (7% / 70%), Taxi 1, Taobao 1, StackOverflow 1 | matches every dedicated winning model exactly (windows on Amazon and Retweet only). The unified model is one configuration plus this rule. Queued: StackOverflow, Taxi, Taobao seeds 0–4 without windows; Retweet seeds 1–4 with windows |
| 8 Oct | unified + window rule, StackOverflow 5 seeds (DEV) | no windows (single-component gaps) | −2.1453 / −2.1411 / −2.1435 / −2.1349 / −2.1406, **mean −2.1411** (with windows −2.1534; dedicated 2-layer −2.1477; dedicated 3-layer −2.1405) | **the rule removes the timing basin** and the 2-layer unified model equals the dedicated 3-layer one |
| 8 Oct | unified, Amazon seeds 0–3 (DEV) | windows on (two components) | 0.8031 / 0.8018 / 0.8021 / 0.8032 vs dedicated v18 0.8042 / 0.8041 / 0.8038 / 0.8036 | stable; −0.0013 on average, the cost of 8 rather than 16 delayed clocks; far above S2P2 0.781 |
| 8 Oct | unified + window rule, Taxi 5 seeds; Taobao seeds 0–3 (DEV) | no windows | Taxi 0.4905 / 0.4940 / 0.4886 / 0.4887 / 0.4884, **mean 0.4900** vs dedicated v5 0.4872 (all five seeds ahead); Taobao 1.2780 / 1.2795 / 1.2832 / 1.2790 vs dedicated 1.2840 / 1.2844 / 1.2829 / 1.2858 | Taxi improves on every seed (+0.0028), where the public margin is narrowest; Taobao −0.004 (dedicated TEST margin over the best published model +0.081) |
| 8 Oct | unified: Taobao seed 4, Amazon seed 4 (DEV) | — | Taobao 1.2782 (dedicated 1.2828): 5-seed mean 1.2796 vs 1.2840; Amazon 0.8046: 5-seed mean 0.8030 vs v18 0.8039 (4 seeds) | Amazon seed 4 above the dedicated range. Taobao −0.004: queued a check without target dequantization (only 87% of Taobao gaps lie on its grid) |
| 8 Oct | Taobao without target dequantization (DEV, 5 seeds) | floor cell kept | 1.2777 / 1.2774 / 1.2820 / 1.2790 / 1.2790, mean 1.2790 vs 1.2796 with it (dedicated 1.2840) | **hypothesis rejected**: dequantization is not the cause. The −0.004 comes from what v19 adds over v5 on Taobao (state clock, cell-held hazards), the mechanisms that win StackOverflow and Retweet. The unified configuration stays as it is; Taobao's TEST margin over the best published model (+0.081) absorbs it |

**Pre-registered unified protocol (fixed 8 Oct 2026 09:45 UTC, before any v19 checkpoint is scored on TEST).** One
configuration for all five datasets: `race_tpp_v19.py`, 2 layers, d 32, 16 memory modes, 2 exponential and 8 delayed
log-normal clocks, 16 state-clock modes, dropout 0.3, patience 30, seeds 0–4. Two data rules, no per-dataset tuning:
(1) logistic windows (4) only when the TRAIN gap histogram separates into ≥ 2 components of ≥ 5% each (Amazon, Retweet);
(2) the recording cell is the data's timestamp resolution (Taxi 1/3600, Taobao 1e−4, StackOverflow 2⁻¹³, Retweet 1,
Amazon none), used for the resolution principle and target-only dequantization. Runs: `b1_r26_{taxi,taobao,stackoverflow}_v19_rule_s{0..4}`,
`b1_r25_{amazon,retweet}_v19_unified_s{0..4}`. Each best-DEV checkpoint is scored **once** on TEST by
`experiments/tpp/score_test.py --out-prefix b1_final_unified_v19_<dataset>` after reproducing its recorded DEV to 1e−9.
Report all 25 TEST values and per-dataset mean ± sd against the best published results (Taobao 1.318, Taxi 0.522,
StackOverflow −2.163, Retweet −6.348, Amazon 0.781), with parameters and per-event MACs. "One configuration wins the
benchmark" is claimed only if the mean is ahead on all five; otherwise the result is reported per dataset as it is.
The dedicated-model wins stay in the record.
| 8 Oct | **unified protocol, TEST (4 of 5 datasets scored)** | pre-registered; all 20 checkpoints reproduced DEV exactly before scoring | Taobao **1.3967 ± 0.0031** (5/5 ahead of 1.318); Taxi **0.5262 ± 0.0034** (4/5 ahead of 0.522; seed 2 0.521); StackOverflow **−2.1436 ± 0.0029** (5/5 ahead of −2.163); Amazon **0.8017 ± 0.0006** (5/5 ahead of 0.781) | one configuration is ahead on the mean on all four, and above the dedicated models on Taxi (0.5250) and StackOverflow (−2.1444). Per-event MACs vs S2P2: Taxi 22,628 vs 249,856 (0.09×), Amazon 30,432 vs 125,568 (0.24×), StackOverflow 29,660 vs 29,216 (1.015×), Taobao 26,730 vs 26,016 (1.03×). Retweet seeds training; no verdict until all five are scored |
| 8 Oct | unified protocol, Retweet seed 0 | pre-registered; DEV reproduced exactly | TEST **−6.3264** (NHP −6.348); grid audit drop **0.0093** on DEV (v16: 0.0038; baseline 0.0006) | ahead; the residual is larger than v16's but under half the margin (dequantized-equivalent ≈ −6.336). Cell floors on windows verified intact in v19; the difference is longer, more regularized training (patience 30, dropout 0.3). Every unified Retweet seed is audited and reported |
| 8 Oct | unified protocol, Retweet seed 1 | pre-registered; DEV reproduced exactly | TEST **−6.3225** (best Retweet TEST so far; dedicated v16 best seed −6.3250; NHP −6.348); audit drop 0.0080 | ahead by 0.026, three times the audit residual. Seeds 2–4 training |
| 8 Oct | unified protocol, Retweet seed 3 | pre-registered; DEV reproduced exactly | TEST −6.3266 (NHP −6.348); audit drop 0.0085 | three of five Retweet seeds ahead; seeds 2 and 4 training |

**Generative mode (curie, 8 Oct; `experiments/tpp/generate_race.py`).** The race of clocks samples exactly: each clock
draws its firing time (Exp(rate·w); defective delayed clocks fire with probability π at LogNormal(μ, σ)), the earliest
gives the time, its mark law the type, and the event is fed back into the memory; no thinning or rejection. Taxi v5
checkpoint (curie reproduction, seed 0), 200 TEST sequences, each continued from its first event to its real length:
gap distribution KS **0.014** vs a marginal-marks/exponential-gaps reference 0.063; mark-transition total variation
**0.024** vs 0.527; log-gap quantiles −3.38/−2.64/−1.91/−1.32/−0.74 vs real −3.42/−2.64/−1.93/−1.33/−0.80. Generated streams
reproduce both timing and the pickup/drop-off alternation (`results/tpp/generate/taxi_v5_s0_generated_200.json`).
| 8 Oct | unified protocol, Retweet seed 2 | pre-registered; DEV reproduced exactly | TEST −6.3231 (NHP −6.348); audit drop 0.0072 | four of five Retweet seeds ahead; seed 4 training |
| 8 Oct | unified protocol, Retweet seed 4 | pre-registered; DEV reproduced exactly | TEST −6.3224; audit drop 0.0082 | all five Retweet seeds ahead |
| 8 Oct | **UNIFIED PROTOCOL VERDICT** | one configuration (v19 + window rule + recording cell), 5 datasets × 5 seeds, TEST once per checkpoint | Taobao **1.3967 ± 0.0031**, Taxi **0.5262 ± 0.0034**, StackOverflow **−2.1436 ± 0.0029**, Retweet **−6.3242 ± 0.0021**, Amazon **0.8017 ± 0.0006**; time / mark LL 2.755 / −1.358, 0.735 / −0.209, −0.642 / −1.502, −5.556 / −0.768, 2.656 / −1.855 | **WIN on all five with one configuration**: 24 of 25 seeds ahead (Taxi seed 2 0.521 vs 0.522). Above our dedicated models on Taxi, StackOverflow and Retweet. Per-event MACs vs S2P2: 1.03×, 0.09×, 1.015×, 0.07×, 0.24×. Retweet audit drops 0.007–0.009. EasyTPP Monte Carlo estimator agrees on all 25 checkpoints within its sampling noise (means: Taobao 1.3967, Taxi 0.5256, StackOverflow −2.1400, Retweet −6.3244, Amazon 0.8035; every gap < 2 estimator sd) |

**Measured streaming inference (curie, 8 Oct; `experiments/tpp/streaming_latency.py`).** An incremental per-event step
(temporal memory states and mark slots carried; next-event distribution after each event) reproduces the batch encoder's
clock parameters to 7e-15 (float64). Taxi v5 checkpoint, batch 1, one CPU thread (Intel i5-4690, other jobs running),
3,706 held-out events: **0.64 ms per event (≈1,570 events/s) in float64, 0.73 ms in float32**. The time is eager-PyTorch
per-operation overhead: the model's arithmetic is 20,708 multiply-accumulates per event (S2P2: 249,856), so a fused
implementation would be far faster (engineering estimate, not measured). Measured as-is, one core keeps up with
event streams of over a thousand events per second.
