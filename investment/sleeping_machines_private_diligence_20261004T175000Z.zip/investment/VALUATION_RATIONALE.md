# Valuation rationale: ambition, platform potential and execution

4 October 2026 · Private founder/investor discussion · Not an independent appraisal.

**Current proposal: raise €3M at €50M priced pre-money.** The €100M case remains
a stretch scenario. The broader family definition strengthens the rationale
for seeking a platform premium; it does not establish a market-clearing price
or a probability of success. The proposal funds the next decisive evidence,
team and execution capacity rather than requiring that the entire vision be
finished before investment.

## 1. The ambition being financed

Sleeping Machines aims to establish a general learning and thinking substrate
that connects content, computational time, persistent evidence, selective work
and learning. The common event/state interface permits heterogeneous local
programs, dense and selective regions, synchronous and asynchronous schedules,
and streamed or batched learning. A chosen member fixes its actual operators and
contracts; broad family membership does not grant every member every capability.

The largest outcome would be a widely adopted model/learning/runtime layer,
with compatible communication and compute substrates from datacenters to mobile
and robotics. Integrated embodied and cognitive learning could expand the core
model's useful reach, with motor experience and reasoning teaching shared
representations. General intelligence is an overarching aspiration, not a
current capability claim or a quantified probability in the financial model.

The [opportunity register](../report/model_family_opportunities.md) gives this
breadth concrete mechanisms and proof conditions. Asynchronous codecs,
irregular-stream ingestion, task-oriented communication, learned memory
policies and embodied transfer are additional possible uses of the same core.
They remain at their stated evidence stages. Familiar neural methods already
address portions of these problems; our investment thesis concerns the useful
integrated construction and its eventual quality/resource behavior.

## 2. Why the platform could earn a premium

| Potential asset | Route to economic value | What must become true |
| --- | --- | --- |
| Models and learning policies | Better useful quality per total learning/inference resource; persistent adaptation | Useful depth, memory credit, scalable discovery and repeated relevant comparisons |
| Runtime and deployment software | Lower full service cost at required quality, latency and reliability | Trained sparse parity and measured traffic, residency, throughput and energy |
| Adaptive communications/codecs | Fewer transmitted bits and less recomputation for reconstruction or a declared task | A real independently decodable wire format and a superior quality/rate/work/latency curve |
| Embodied generalist learning | Share useful representations across sensing, acting, language and reasoning | Joint learning and separately measured transfer in both directions, including held-out tasks |
| Compute/hardware IP | Co-design local state, scheduling and communication for target platforms | Precision, scheduling, memory/interconnect and physical energy economics demonstrated |

One successful deployment can provide value before the full platform exists.
Reusable mechanisms and tooling could then lower the cost of entering adjacent
workloads. Value capture could include model/runtime licensing, deployment
software, communication SDKs, accelerator IP and later hardware. These are
commercial hypotheses; neither vendor strategic fit nor repository privacy
establishes customer interest, legal exclusivity or adoption.

These opportunities are correlated through shared learning and execution
dependencies. Do not add their entire markets, count them as independent
success probabilities or infer a present price from hypothetical endpoint TAM.
The upside supports a premium only alongside credible execution and a path to
capturing part of the value created.

## 3. Execution evidence makes the ambition more than an idea

The project has progressed from a manifesto to implemented temporal/state
mechanisms, integrated language models, controlled mechanism comparisons,
source-bound results and a formal family with explicit composition/learning
contracts. This is evidence of research execution, not yet evidence of operating
a scaled company or deploying a frontier product.

The [current evidence map](../report/architecture_evidence.md) supplies anchors:

- Matched value-informed route credit improves 2.506386→2.371491 BPC for about
  0.30% extra estimated fitting work. This supports a core learning mechanism.
- Doubling available receiver capacity improves 2.371491→2.345157 BPC with
  eight selected writes retained; fitting work rises about 1.650×. Useful
  capacity beyond activity is supported within that scope, with costs charged.
- A completed 90M-trained member reaches 1.857306 BPC on the restricted
  test[95M:96M] region, T256. It supplies larger-data learning evidence, with
  changed width/data, one seed and no full official-test or matched-scale win.
- An earlier causal neural online pilot improves 3.190859→3.095738 BPC at
  10.736× processing work. Adaptation is possible within that scope; economical
  native adaptation remains to be demonstrated.

These anchors are exploratory and single-seed. The retained negative findings,
causal-protocol corrections, numerical contracts and full-resource definitions
help make the program reviewable. The future premium depends on turning this
execution discipline into replicated, deployable benefits.

Tero Keski-Valkama is the sole founder. His public
[professional history](https://www.xing.com/profile/Tero_KeskiValkama) and
[project portfolio](https://keskival.github.io/) support relevant applied-ML and
software-architecture experience, subject to reference/availability diligence.
The published [EP4148389A2 application](https://patentimages.storage.googleapis.com/25/dd/41/af29b8e1391162/EP4148389A2.pdf)
names him as inventor and HERE Global B.V. as applicant; it is evidence of
invention experience, not a granted venture-owned asset. Sole-founder status
does not imply sole research authorship: preserve Karoliina Salminen's credit
and resolve contributions, employment assignments and licensing.

The proposed €3M buys an 18-month increase in research and engineering capacity:
€1.35M team, €0.90M compute/replication, €0.25M hardware feasibility/measurement,
€0.20M legal/IP/operations and €0.30M reserve. The six-average-FTE staffing and
costs are planning assumptions. Hire complementary learning, runtime and
evaluation skills; stage spending by proof gates. Aggressive scope requires
concentrated tests and a team, rather than launching every application at once.

## 4. What financing precedents establish

[Sakana AI's January 2024 announcement](https://sakana.ai/seed-round/) reports
a $30M seed raise and an experienced founding/research team, including a
Transformer co-creator. [Fractile's transaction adviser](https://www.goodwinlaw.com/en/news-and-events/news/2024/07/announcements-technology-fractile-raises-15-million-in-seed-funding)
reports its $15M seed financing in July 2024 for new AI chips and systems.
These primary announcements show that investors fund ambitious architecture
and computing-substrate programs at an early stage. Neither cited announcement
discloses a priced pre-money valuation; funding amounts are not valuation
comparables, and team/maturity differences prevent direct price transfer.

The implication is that the category is investable. It does not establish that
our €50M or €100M proposal is accepted or typical. A suitable deep-tech investor
must independently assess founder/team execution, reproducibility, rights,
capital needs, competitive alternatives and the eventual value-capture route.

## 5. Interpret the two prices explicitly

| Proposed priced pre-money | €3M post-money | Initial new-investor stake | Interpretation |
| --- | --- | --- | --- |
| €50M | €53M | 5.6604% | Ambitious current opening price for the model/learning/runtime/substrate opportunity |
| €100M | €103M | 2.9126% | Stretch case requiring stronger conviction, financing competition or additional de-risking |

Ownership excludes option-pool changes, preferences, fees and later financing.
At tenfold gross proceeds, a €3M investor needs €30M: absent later dilution,
that corresponds to €530M or €1.03B exit equity value under the respective
rows. Further dilution raises the required outcome. This is conditional equity
arithmetic, not an exit forecast or a discount-rate-adjusted return estimate.

**Assessment:** €50M remains aligned with the ambition as an aggressive,
evidence-informed negotiating thesis. The new definition/opportunities strengthen
the explanation of potential value, while their untested status leaves much
of the financing risk unchanged. €100M is a stretch scenario. We should not
present either as already established fair value. Research progress can justify
a premium before revenue; investor demand and terms determine attainability.

The highest-value next evidence is a repeated useful-quality/full-cost advantage,
trained sparse deployment, effective delayed memory learning and a capable team
with usable rights. Embodied transfer and asynchronous codecs add potentially
large expansion options, each earned through its own measured first proof.
Keep the bold platform vision and explicit execution milestones together.
